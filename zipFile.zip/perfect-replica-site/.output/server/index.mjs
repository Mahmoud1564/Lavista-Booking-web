globalThis.__nitro_main__ = import.meta.url;
import { a as FastResponse, n as HTTPError, r as defineLazyEventHandler, t as H3Core } from "./_libs/h3+rou3+srvx.mjs";
import { t as HookableCore } from "./_libs/hookable.mjs";
//#region #nitro-vite-setup
function lazyService(loader) {
	let promise, mod;
	return { fetch(req) {
		if (mod) return mod.fetch(req);
		if (!promise) promise = loader().then((_mod) => mod = _mod.default || _mod);
		return promise.then((mod) => mod.fetch(req));
	} };
}
var services = { ["ssr"]: lazyService(() => import("./_ssr/ssr.mjs")) };
globalThis.__nitro_vite_envs__ = services;
//#endregion
//#region #nitro/virtual/public-assets-data
var public_assets_data_default = {
	"/exp-nile.jpg": {
		"type": "image/jpeg",
		"etag": "\"15b55-J5pfLlT3QvEESgxY9lhTkv6JVTs\"",
		"mtime": "2026-07-05T23:34:00.776Z",
		"size": 88917,
		"path": "../public/exp-nile.jpg"
	},
	"/exp-desert.jpg": {
		"type": "image/jpeg",
		"etag": "\"a241-3VJgqdt4gU9HARnyOpDCp7T3dRY\"",
		"mtime": "2026-07-05T23:34:00.776Z",
		"size": 41537,
		"path": "../public/exp-desert.jpg"
	},
	"/exp-food.jpg": {
		"type": "image/jpeg",
		"etag": "\"20b49-0XgZznlDdaqSE+DFLMQ1pfhYJn8\"",
		"mtime": "2026-07-05T23:34:00.776Z",
		"size": 133961,
		"path": "../public/exp-food.jpg"
	},
	"/exp-pyramids.jpg": {
		"type": "image/jpeg",
		"etag": "\"88b7-nB4gjF4fjvkd6uI5mJltk/hJz8w\"",
		"mtime": "2026-07-05T23:34:00.776Z",
		"size": 34999,
		"path": "../public/exp-pyramids.jpg"
	},
	"/gallery-cairo.jpg": {
		"type": "image/jpeg",
		"etag": "\"2457b-kVW1Jr4px4XfMb4OG4GoMQ/BLew\"",
		"mtime": "2026-07-05T23:34:00.776Z",
		"size": 148859,
		"path": "../public/gallery-cairo.jpg"
	},
	"/gallery-lounge.jpg": {
		"type": "image/jpeg",
		"etag": "\"2a956-4WyJgFqxVCHnToPIPakAGmzXMNw\"",
		"mtime": "2026-07-05T23:34:00.776Z",
		"size": 174422,
		"path": "../public/gallery-lounge.jpg"
	},
	"/gallery-pyramids.jpg": {
		"type": "image/jpeg",
		"etag": "\"c715-hB8g/IrlgC80ISs0ogdJ7aMOYG4\"",
		"mtime": "2026-07-05T23:34:00.776Z",
		"size": 50965,
		"path": "../public/gallery-pyramids.jpg"
	},
	"/room-1.jpg": {
		"type": "image/jpeg",
		"etag": "\"18e10-QPpNZZL/2Abf6i9U26lw9+Un5KI\"",
		"mtime": "2026-07-05T23:34:00.776Z",
		"size": 101904,
		"path": "../public/room-1.jpg"
	},
	"/room-2.jpg": {
		"type": "image/jpeg",
		"etag": "\"1d802-leyWHrKzxUN8EIbdY80Q/i+hC0o\"",
		"mtime": "2026-07-05T23:34:00.777Z",
		"size": 120834,
		"path": "../public/room-2.jpg"
	},
	"/assets/Footer-BgJMZ0QU.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"d52-J1CoSR5c8j1/xI/2NJMMjaCBseE\"",
		"mtime": "2026-07-05T23:33:59.626Z",
		"size": 3410,
		"path": "../public/assets/Footer-BgJMZ0QU.js"
	},
	"/assets/arrow-right-qHEWS3gm.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"a5-XftnN89QuEipSqPWgdE/0zCNoao\"",
		"mtime": "2026-07-05T23:33:59.629Z",
		"size": 165,
		"path": "../public/assets/arrow-right-qHEWS3gm.js"
	},
	"/assets/booking-DUgyjYEw.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"150f-Iph01Bf2CxafViJdqHZ3Vrjw/gU\"",
		"mtime": "2026-07-05T23:33:59.629Z",
		"size": 5391,
		"path": "../public/assets/booking-DUgyjYEw.js"
	},
	"/assets/booking-api-Cac8pRFM.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1916-EtvJJQJYdhqfm7Co4m1d7d3012g\"",
		"mtime": "2026-07-05T23:33:59.629Z",
		"size": 6422,
		"path": "../public/assets/booking-api-Cac8pRFM.js"
	},
	"/assets/booking-context-B2ZovxVR.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"34a-QA80rQbkUqyzLqjdTQibm7YQWmU\"",
		"mtime": "2026-07-05T23:33:59.629Z",
		"size": 842,
		"path": "../public/assets/booking-context-B2ZovxVR.js"
	},
	"/assets/booking-flow-CPaIE9LA.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"4a4-a7phsq2dPAxdlomxrpejVbrHtZM\"",
		"mtime": "2026-07-05T23:33:59.630Z",
		"size": 1188,
		"path": "../public/assets/booking-flow-CPaIE9LA.js"
	},
	"/assets/booking-flow-ui-BBzGTnj8.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"828-c3/p8uFfmJ9zbDmfI1md5G2z8yU\"",
		"mtime": "2026-07-05T23:33:59.630Z",
		"size": 2088,
		"path": "../public/assets/booking-flow-ui-BBzGTnj8.js"
	},
	"/assets/arrow-left-C0obLcZA.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"a5-dQKRH/I0M8xo7Td/ARiSbPpilyw\"",
		"mtime": "2026-07-05T23:33:59.629Z",
		"size": 165,
		"path": "../public/assets/arrow-left-C0obLcZA.js"
	},
	"/gallery-rooftop.jpg": {
		"type": "image/jpeg",
		"etag": "\"23de7-EzEndRwsNABv6ssUT5RpYO2phek\"",
		"mtime": "2026-07-05T23:34:00.776Z",
		"size": 146919,
		"path": "../public/gallery-rooftop.jpg"
	},
	"/assets/booking-server-fns-BSEXBXXf.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1298-FEf+b3qpfBMkcv5CUr3rnAn2J7s\"",
		"mtime": "2026-07-05T23:33:59.630Z",
		"size": 4760,
		"path": "../public/assets/booking-server-fns-BSEXBXXf.js"
	},
	"/assets/booking.dates-BOVkn3Rv.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1046-y24sENHCXPZq1DBb+v0pFB93jqo\"",
		"mtime": "2026-07-05T23:33:59.630Z",
		"size": 4166,
		"path": "../public/assets/booking.dates-BOVkn3Rv.js"
	},
	"/assets/booking.confirmation._ref-4oZpHb8O.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1db1-u4hKvOF2m3j95py+mXzVczS4muM\"",
		"mtime": "2026-07-05T23:33:59.630Z",
		"size": 7601,
		"path": "../public/assets/booking.confirmation._ref-4oZpHb8O.js"
	},
	"/assets/booking.extras-BPwyieKX.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"571-nb4itRjsmUbBsYy0B5V0D1qaOKY\"",
		"mtime": "2026-07-05T23:33:59.630Z",
		"size": 1393,
		"path": "../public/assets/booking.extras-BPwyieKX.js"
	},
	"/assets/booking.guest-BhvzwIcH.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"3885-Dlt24dyNpr7v3t7ovv7SpPf9xU8\"",
		"mtime": "2026-07-05T23:33:59.630Z",
		"size": 14469,
		"path": "../public/assets/booking.guest-BhvzwIcH.js"
	},
	"/room-3.jpg": {
		"type": "image/jpeg",
		"etag": "\"14dde-Mal8InkTgGCR+U8vpeJ9uSuTzEo\"",
		"mtime": "2026-07-05T23:34:00.777Z",
		"size": 85470,
		"path": "../public/room-3.jpg"
	},
	"/hero-pyramids.jpg": {
		"type": "image/jpeg",
		"etag": "\"2bbd4-8B96g6HnwOkoBVpXHiapiXMINqk\"",
		"mtime": "2026-07-05T23:34:00.777Z",
		"size": 179156,
		"path": "../public/hero-pyramids.jpg"
	},
	"/assets/booking.payment-DCPwiy2j.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"19bf-0OFgcNppJh5piXfmuKu1fUkF1us\"",
		"mtime": "2026-07-05T23:33:59.630Z",
		"size": 6591,
		"path": "../public/assets/booking.payment-DCPwiy2j.js"
	},
	"/assets/booking.rooms-CsHAkSM0.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"14ce-ihE3IF8kHTPKhMk3JbAmLgg8j2U\"",
		"mtime": "2026-07-05T23:33:59.630Z",
		"size": 5326,
		"path": "../public/assets/booking.rooms-CsHAkSM0.js"
	},
	"/assets/bookings-C7asGgck.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"301-idO2h7Ox8jKJfmROJSkDMQ6g+D0\"",
		"mtime": "2026-07-05T23:33:59.630Z",
		"size": 769,
		"path": "../public/assets/bookings-C7asGgck.js"
	},
	"/assets/button-Cfxtnbnl.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"dd6-I/lELyaf7ViEVRvp+q/X9ANvidI\"",
		"mtime": "2026-07-05T23:33:59.630Z",
		"size": 3542,
		"path": "../public/assets/button-Cfxtnbnl.js"
	},
	"/assets/calendar-C_Om1MCq.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"117cd-BIDjqHnYIOkBPLni6vejl2G0+8I\"",
		"mtime": "2026-07-05T23:33:59.632Z",
		"size": 71629,
		"path": "../public/assets/calendar-C_Om1MCq.js"
	},
	"/assets/calendar-days-B_mtDQZx.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1ee-DxVqyexst+ImteX+iOxNItDMRPk\"",
		"mtime": "2026-07-05T23:33:59.633Z",
		"size": 494,
		"path": "../public/assets/calendar-days-B_mtDQZx.js"
	},
	"/assets/check-CIlnx28k.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"7c-df7AHmerX7jDha5+/Iq03rRnCkA\"",
		"mtime": "2026-07-05T23:33:59.633Z",
		"size": 124,
		"path": "../public/assets/check-CIlnx28k.js"
	},
	"/assets/circle-alert-B-IVAjuZ.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"fa-CrDYs3ukgj7B2lqtoQq1GwDSNEo\"",
		"mtime": "2026-07-05T23:33:59.633Z",
		"size": 250,
		"path": "../public/assets/circle-alert-B-IVAjuZ.js"
	},
	"/assets/createLucideIcon-orx4IUyc.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"4a4-Uk+vPexYBal8VBgVe6hmM8c//dQ\"",
		"mtime": "2026-07-05T23:33:59.634Z",
		"size": 1188,
		"path": "../public/assets/createLucideIcon-orx4IUyc.js"
	},
	"/assets/differenceInCalendarDays-BK1ZjWX5.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2f2-8qildjCwjrDz1uOAyg7aIPiWGlQ\"",
		"mtime": "2026-07-05T23:33:59.634Z",
		"size": 754,
		"path": "../public/assets/differenceInCalendarDays-BK1ZjWX5.js"
	},
	"/assets/dist-C8QakbHo.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"68cc-N0+PDxFGN06Fg+G5ywTizAt8/3A\"",
		"mtime": "2026-07-05T23:33:59.634Z",
		"size": 26828,
		"path": "../public/assets/dist-C8QakbHo.js"
	},
	"/assets/download-CQHazL0f.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"e8-zUl72TnxEkd9rBzPIb3eU3f8X50\"",
		"mtime": "2026-07-05T23:33:59.634Z",
		"size": 232,
		"path": "../public/assets/download-CQHazL0f.js"
	},
	"/assets/exp-desert-DrxEwZjO.jpg": {
		"type": "image/jpeg",
		"etag": "\"a241-3VJgqdt4gU9HARnyOpDCp7T3dRY\"",
		"mtime": "2026-07-05T23:33:59.636Z",
		"size": 41537,
		"path": "../public/assets/exp-desert-DrxEwZjO.jpg"
	},
	"/assets/carousel-BcXKhi5d.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"23009-T6huJ+ZuYifjWIk1z9gY9EHqI4Q\"",
		"mtime": "2026-07-05T23:33:59.633Z",
		"size": 143369,
		"path": "../public/assets/carousel-BcXKhi5d.js"
	},
	"/assets/exp-pyramids-Bxz2FRZX.jpg": {
		"type": "image/jpeg",
		"etag": "\"88b7-nB4gjF4fjvkd6uI5mJltk/hJz8w\"",
		"mtime": "2026-07-05T23:33:59.637Z",
		"size": 34999,
		"path": "../public/assets/exp-pyramids-Bxz2FRZX.jpg"
	},
	"/assets/experiences._slug-CKNEZUyE.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1906-yM8oqA31HPXu9cNoOLgsIqliSlI\"",
		"mtime": "2026-07-05T23:33:59.634Z",
		"size": 6406,
		"path": "../public/assets/experiences._slug-CKNEZUyE.js"
	},
	"/assets/format-DiZflMCn.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"48c3-3VZX7Wut0Y6ILTtrZmMx3n6kGr8\"",
		"mtime": "2026-07-05T23:33:59.634Z",
		"size": 18627,
		"path": "../public/assets/format-DiZflMCn.js"
	},
	"/assets/exp-nile-C4Cft5kn.jpg": {
		"type": "image/jpeg",
		"etag": "\"15b55-J5pfLlT3QvEESgxY9lhTkv6JVTs\"",
		"mtime": "2026-07-05T23:33:59.637Z",
		"size": 88917,
		"path": "../public/assets/exp-nile-C4Cft5kn.jpg"
	},
	"/assets/exp-food-CFASKmp3.jpg": {
		"type": "image/jpeg",
		"etag": "\"20b49-0XgZznlDdaqSE+DFLMQ1pfhYJn8\"",
		"mtime": "2026-07-05T23:33:59.636Z",
		"size": 133961,
		"path": "../public/assets/exp-food-CFASKmp3.jpg"
	},
	"/assets/gallery-cairo-CSLzUgUR.jpg": {
		"type": "image/jpeg",
		"etag": "\"2457b-kVW1Jr4px4XfMb4OG4GoMQ/BLew\"",
		"mtime": "2026-07-05T23:33:59.637Z",
		"size": 148859,
		"path": "../public/assets/gallery-cairo-CSLzUgUR.jpg"
	},
	"/assets/hero-pyramids-DADob_Ms.jpg": {
		"type": "image/jpeg",
		"etag": "\"2bbd4-8B96g6HnwOkoBVpXHiapiXMINqk\"",
		"mtime": "2026-07-05T23:33:59.640Z",
		"size": 179156,
		"path": "../public/assets/hero-pyramids-DADob_Ms.jpg"
	},
	"/assets/gallery-rooftop-DMNbtY3B.jpg": {
		"type": "image/jpeg",
		"etag": "\"23de7-EzEndRwsNABv6ssUT5RpYO2phek\"",
		"mtime": "2026-07-05T23:33:59.639Z",
		"size": 146919,
		"path": "../public/assets/gallery-rooftop-DMNbtY3B.jpg"
	},
	"/assets/link-CsShC-rv.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"8cde-uOAX+tZR6daWvnSmN389w95DyU8\"",
		"mtime": "2026-07-05T23:33:59.634Z",
		"size": 36062,
		"path": "../public/assets/link-CsShC-rv.js"
	},
	"/assets/gallery-lounge-Cukc-D6a.jpg": {
		"type": "image/jpeg",
		"etag": "\"2a956-4WyJgFqxVCHnToPIPakAGmzXMNw\"",
		"mtime": "2026-07-05T23:33:59.638Z",
		"size": 174422,
		"path": "../public/assets/gallery-lounge-Cukc-D6a.jpg"
	},
	"/assets/index-5Islgbg9.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"8041b-nyijO4AG25aEoeUI5vEG5NVcQak\"",
		"mtime": "2026-07-05T23:33:59.622Z",
		"size": 525339,
		"path": "../public/assets/index-5Islgbg9.js"
	},
	"/assets/manage-booking-D3o3uDYk.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2730-mox5Xm53DQteJC2PPiTg7EtJDiw\"",
		"mtime": "2026-07-05T23:33:59.634Z",
		"size": 10032,
		"path": "../public/assets/manage-booking-D3o3uDYk.js"
	},
	"/assets/matchContext-ButN7OQN.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"9b-UPDGsZ4UFY/6EYo4uYaBCxPi29I\"",
		"mtime": "2026-07-05T23:33:59.634Z",
		"size": 155,
		"path": "../public/assets/matchContext-ButN7OQN.js"
	},
	"/assets/message-circle-vBB47giE.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1bf-f1hDljFukSE8/CU+ZcwfT+OP+7o\"",
		"mtime": "2026-07-05T23:33:59.634Z",
		"size": 447,
		"path": "../public/assets/message-circle-vBB47giE.js"
	},
	"/assets/popover-3Wyulcmj.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"e44f-Pv5QxkKAIvkk1l03gRYd+alL5t4\"",
		"mtime": "2026-07-05T23:33:59.634Z",
		"size": 58447,
		"path": "../public/assets/popover-3Wyulcmj.js"
	},
	"/assets/preselect-room-NcUZaX_L.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"107-zizJYGJUsHzw5ukidoBYdlWXlTM\"",
		"mtime": "2026-07-05T23:33:59.635Z",
		"size": 263,
		"path": "../public/assets/preselect-room-NcUZaX_L.js"
	},
	"/assets/redirect-C-eRQtnH.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"22d-XWldT6wFIL00QHpfP609loBAcNQ\"",
		"mtime": "2026-07-05T23:33:59.635Z",
		"size": 557,
		"path": "../public/assets/redirect-C-eRQtnH.js"
	},
	"/assets/rooms._id-XPWBsRAW.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1f11-49v6F2+eiZmKZC2AZNqoo1AirDI\"",
		"mtime": "2026-07-05T23:33:59.635Z",
		"size": 7953,
		"path": "../public/assets/rooms._id-XPWBsRAW.js"
	},
	"/assets/routes-_0USCEDp.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"c1d8-mNuvoqqMIokwowU9QsVYCfBtDcY\"",
		"mtime": "2026-07-05T23:33:59.635Z",
		"size": 49624,
		"path": "../public/assets/routes-_0USCEDp.js"
	},
	"/assets/search-BJlnKS4M.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"ae-w9caBsPBWcdIbWabSgfstDGWcXk\"",
		"mtime": "2026-07-05T23:33:59.635Z",
		"size": 174,
		"path": "../public/assets/search-BJlnKS4M.js"
	},
	"/assets/tslib.es6-Tae09705.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"42d-qJHuGuq51+EbLaebsBAkbj1JLbk\"",
		"mtime": "2026-07-05T23:33:59.635Z",
		"size": 1069,
		"path": "../public/assets/tslib.es6-Tae09705.js"
	},
	"/assets/use-content-jLc09cpB.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"20b-xWCwm7m/ssrQGGks3hWOLh9ht1E\"",
		"mtime": "2026-07-05T23:33:59.635Z",
		"size": 523,
		"path": "../public/assets/use-content-jLc09cpB.js"
	},
	"/assets/use-rooms-xBXnHinV.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1c2-uD8rXbhBnFYovDHsws4wphHAw1Q\"",
		"mtime": "2026-07-05T23:33:59.635Z",
		"size": 450,
		"path": "../public/assets/use-rooms-xBXnHinV.js"
	},
	"/assets/useQuery-VmZ4NBUL.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"223a-/uDbnUiTgxaD0CZP/ONWjNAggFY\"",
		"mtime": "2026-07-05T23:33:59.636Z",
		"size": 8762,
		"path": "../public/assets/useQuery-VmZ4NBUL.js"
	},
	"/assets/styles-BrTjb_cu.css": {
		"type": "text/css; charset=utf-8",
		"etag": "\"1a9de-xCJtrvY6vyuRNJ1Y7Dt/pZdxN08\"",
		"mtime": "2026-07-05T23:33:59.641Z",
		"size": 109022,
		"path": "../public/assets/styles-BrTjb_cu.css"
	},
	"/assets/users-CUKlAsux.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"132-E8Nqwttcq6uNZ194Rf0u9tP3nHo\"",
		"mtime": "2026-07-05T23:33:59.636Z",
		"size": 306,
		"path": "../public/assets/users-CUKlAsux.js"
	}
};
//#endregion
//#region #nitro/virtual/public-assets
var publicAssetBases = {};
function isPublicAssetURL(id = "") {
	if (public_assets_data_default[id]) return true;
	for (const base in publicAssetBases) if (id.startsWith(base)) return true;
	return false;
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/route-rules.mjs
var headers = ((m) => function headersRouteRule(event) {
	for (const [key, value] of Object.entries(m.options || {})) event.res.headers.set(key, value);
});
//#endregion
//#region #nitro/virtual/routing
var findRouteRules = /* @__PURE__ */ (() => {
	const $0 = [{
		name: "headers",
		route: "/assets/**",
		handler: headers,
		options: { "cache-control": "public, max-age=31536000, immutable" }
	}];
	return (m, p) => {
		let r = [];
		if (p.charCodeAt(p.length - 1) === 47) p = p.slice(0, -1) || "/";
		let s = p.split("/");
		if (s.length > 1) {
			if (s[1] === "assets") r.unshift({
				data: $0,
				params: { "_": s.slice(2).join("/") }
			});
		}
		return r;
	};
})();
var _lazy_JShPQo = defineLazyEventHandler(() => import("./_chunks/ssr-renderer.mjs"));
var findRoute = /* @__PURE__ */ (() => {
	const data = {
		route: "/**",
		handler: _lazy_JShPQo
	};
	return ((_m, p) => {
		return {
			data,
			params: { "_": p.slice(1) }
		};
	});
})();
[].filter(Boolean);
//#endregion
//#region node_modules/nitro/dist/runtime/internal/error/prod.mjs
var errorHandler = (error, event) => {
	const res = defaultHandler(error, event);
	return new FastResponse(typeof res.body === "string" ? res.body : JSON.stringify(res.body, null, 2), res);
};
function defaultHandler(error, event) {
	const unhandled = error.unhandled ?? !HTTPError.isError(error);
	const { status = 500, statusText = "" } = unhandled ? {} : error;
	if (status === 404) {
		const url = event.url || new URL(event.req.url);
		const baseURL = "/";
		if (/^\/[^/]/.test(baseURL) && !url.pathname.startsWith(baseURL)) return {
			status: 302,
			headers: new Headers({ location: `${baseURL}${url.pathname.slice(1)}${url.search}` })
		};
	}
	const headers = new Headers(unhandled ? {} : error.headers);
	headers.set("content-type", "application/json; charset=utf-8");
	return {
		status,
		statusText,
		headers,
		body: {
			error: true,
			...unhandled ? {
				status,
				unhandled: true
			} : typeof error.toJSON === "function" ? error.toJSON() : {
				status,
				statusText,
				message: error.message
			}
		}
	};
}
//#endregion
//#region #nitro/virtual/error-handler
var errorHandlers = [errorHandler];
async function error_handler_default(error, event) {
	for (const handler of errorHandlers) try {
		const response = await handler(error, event, { defaultHandler });
		if (response) return response;
	} catch (error) {
		console.error(error);
	}
}
//#endregion
//#region #nitro/virtual/app
function createNitroApp() {
	const captureError = (error, errorCtx) => {
		if (errorCtx?.event) {
			const errors = errorCtx.event.req.context?.nitro?.errors;
			if (errors) errors.push({
				error,
				context: errorCtx
			});
		}
	};
	const h3App = createH3App({ onError(error, event) {
		return error_handler_default(error, event);
	} });
	let appHandler = (req) => {
		req.context ||= {};
		req.context.nitro = req.context.nitro || { errors: [] };
		return h3App.fetch(req);
	};
	return {
		fetch: appHandler,
		h3: h3App,
		hooks: void 0,
		captureError
	};
}
function createH3App(config) {
	const h3App = new H3Core(config);
	h3App["~findRoute"] = (event) => findRoute(event.req.method, event.url.pathname);
	h3App["~getMiddleware"] = (event, route) => {
		const pathname = event.url.pathname;
		const method = event.req.method;
		const middleware = [];
		const routeRules = getRouteRules(method, pathname);
		event.context.routeRules = routeRules?.routeRules;
		if (routeRules?.routeRuleMiddleware.length) middleware.push(...routeRules.routeRuleMiddleware);
		if (route?.data?.middleware?.length) middleware.push(...route.data.middleware);
		return middleware;
	};
	return h3App;
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/app.mjs
var APP_ID = "default";
function useNitroApp() {
	let instance = useNitroApp._instance;
	if (instance) return instance;
	instance = useNitroApp._instance = createNitroApp();
	globalThis.__nitro__ = globalThis.__nitro__ || {};
	globalThis.__nitro__[APP_ID] = instance;
	return instance;
}
function useNitroHooks() {
	const nitroApp = useNitroApp();
	const hooks = nitroApp.hooks;
	if (hooks) return hooks;
	return nitroApp.hooks = new HookableCore();
}
function getRouteRules(method, pathname) {
	const m = findRouteRules(method, pathname);
	if (!m?.length) return { routeRuleMiddleware: [] };
	const routeRules = {};
	for (const layer of m) for (const rule of layer.data) {
		const currentRule = routeRules[rule.name];
		if (currentRule) {
			if (rule.options === false) {
				delete routeRules[rule.name];
				continue;
			}
			if (typeof currentRule.options === "object" && typeof rule.options === "object") currentRule.options = {
				...currentRule.options,
				...rule.options
			};
			else currentRule.options = rule.options;
			currentRule.route = rule.route;
			currentRule.params = {
				...currentRule.params,
				...layer.params
			};
		} else if (rule.options !== false) routeRules[rule.name] = {
			...rule,
			params: layer.params
		};
	}
	const middleware = [];
	const orderedRules = Object.values(routeRules).sort((a, b) => (a.handler?.order || 0) - (b.handler?.order || 0));
	for (const rule of orderedRules) {
		if (rule.options === false || !rule.handler) continue;
		middleware.push(rule.handler(rule));
	}
	return {
		routeRules,
		routeRuleMiddleware: middleware
	};
}
//#endregion
//#region node_modules/nitro/dist/presets/cloudflare/runtime/_module-handler.mjs
function createHandler(hooks) {
	const nitroApp = useNitroApp();
	const nitroHooks = useNitroHooks();
	return {
		async fetch(request, env, context) {
			globalThis.__env__ = env;
			augmentReq(request, {
				env,
				context
			});
			const ctxExt = {};
			const url = new URL(request.url);
			if (hooks.fetch) {
				const res = await hooks.fetch(request, env, context, url, ctxExt);
				if (res) return res;
			}
			return await nitroApp.fetch(request);
		},
		scheduled(controller, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:scheduled", {
				controller,
				env,
				context
			}) || Promise.resolve());
		},
		email(message, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:email", {
				message,
				event: message,
				env,
				context
			}) || Promise.resolve());
		},
		queue(batch, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:queue", {
				batch,
				event: batch,
				env,
				context
			}) || Promise.resolve());
		},
		tail(traces, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:tail", {
				traces,
				env,
				context
			}) || Promise.resolve());
		},
		trace(traces, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:trace", {
				traces,
				env,
				context
			}) || Promise.resolve());
		}
	};
}
function augmentReq(cfReq, ctx) {
	const req = cfReq;
	req.ip = cfReq.headers.get("cf-connecting-ip") || void 0;
	req.runtime ??= { name: "cloudflare" };
	req.runtime.cloudflare = {
		...req.runtime.cloudflare,
		...ctx
	};
	req.waitUntil = ctx.context?.waitUntil.bind(ctx.context);
}
//#endregion
//#region node_modules/nitro/dist/presets/cloudflare/runtime/cloudflare-module.mjs
var cloudflare_module_default = createHandler({ fetch(cfRequest, env, context, url) {
	if (env.ASSETS && isPublicAssetURL(url.pathname)) return env.ASSETS.fetch(cfRequest);
} });
//#endregion
export { cloudflare_module_default as default };
