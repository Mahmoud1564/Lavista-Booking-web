import { h as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { n as useBookingFlow } from "./booking-flow-D89pOZ68.mjs";
import { n as StepCard, r as StepNav, t as FieldLabel } from "./booking-flow-ui-Bi1pQ2w4.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/booking.extras-oEndh21n.js
var import_jsx_runtime = require_jsx_runtime();
var TIMES = [
	"Before 12:00",
	"12:00–15:00",
	"15:00–18:00",
	"18:00–21:00",
	"After 21:00",
	"Not sure yet"
];
function ExtrasStep() {
	const { draft, setDraft } = useBookingFlow();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StepCard, {
		title: "Optional details",
		subtitle: "Help us get your arrival just right. You can skip this step.",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-5",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, { children: "Estimated arrival time" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-3 flex flex-wrap gap-2",
				children: TIMES.map((t) => {
					const active = draft.arrivalTime === t;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setDraft({ arrivalTime: active ? "" : t }),
						className: `rounded-full border px-4 py-2 text-xs transition ${active ? "border-gold bg-gold/10 text-gold" : "border-gold/20 text-sand-soft/80 hover:border-gold/40"}`,
						children: t
					}, t);
				})
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, { children: "Special requests" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
				rows: 4,
				value: draft.specialRequests,
				onChange: (e) => setDraft({ specialRequests: e.target.value }),
				placeholder: "Airport pickup, dietary preferences, early check-in…",
				className: "mt-2 w-full rounded-xl border border-gold/20 bg-ink/30 p-3 text-sm text-sand-soft outline-none focus:border-gold"
			})] })]
		})
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StepNav, {
		back: "/booking/dates",
		next: "/booking/payment"
	})] });
}
//#endregion
export { ExtrasStep as component };
