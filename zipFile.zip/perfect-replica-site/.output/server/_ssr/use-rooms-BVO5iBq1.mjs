import { c as fetchUnavailableRoomIds, o as fetchRoom, s as fetchRooms } from "./booking-api-BfQOc4Uq.mjs";
import { t as useQuery } from "../_libs/tanstack__react-query.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/use-rooms-BVO5iBq1.js
function useRooms() {
	return useQuery({
		queryKey: ["rooms"],
		queryFn: fetchRooms,
		staleTime: 6e4
	});
}
function useRoom(id) {
	return useQuery({
		queryKey: ["room", id],
		queryFn: () => fetchRoom(id),
		enabled: !!id,
		staleTime: 6e4
	});
}
function useUnavailableRooms(checkIn, checkOut) {
	return useQuery({
		queryKey: [
			"unavailable",
			checkIn?.toISOString().slice(0, 10),
			checkOut?.toISOString().slice(0, 10)
		],
		queryFn: () => fetchUnavailableRoomIds(checkIn, checkOut),
		enabled: !!checkIn && !!checkOut,
		staleTime: 3e4
	});
}
//#endregion
export { useRooms as n, useUnavailableRooms as r, useRoom as t };
