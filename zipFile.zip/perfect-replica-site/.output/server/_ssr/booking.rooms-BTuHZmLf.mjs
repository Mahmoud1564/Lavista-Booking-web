import { h as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { n as useBooking } from "./booking-context-DnMtMm7a.mjs";
import { n as useBookingFlow } from "./booking-flow-D89pOZ68.mjs";
import { n as useRooms, r as useUnavailableRooms } from "./use-rooms-BVO5iBq1.mjs";
import { f as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { E as Check, S as CircleAlert, g as Eye, o as Plus, t as X } from "../_libs/lucide-react.mjs";
import { n as StepCard, r as StepNav } from "./booking-flow-ui-Bi1pQ2w4.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/booking.rooms-BTuHZmLf.js
var import_jsx_runtime = require_jsx_runtime();
function RoomsStep() {
	const { draft, addRoom, removeRoom } = useBookingFlow();
	const { guests, checkIn, checkOut } = useBooking();
	const { data: rooms = [], isLoading } = useRooms();
	const { data: unavailable } = useUnavailableRooms(checkIn, checkOut);
	const selected = draft.rooms.map((id) => rooms.find((r) => r.id === id)).filter((r) => Boolean(r));
	const totalCapacity = selected.reduce((s, r) => s + r.capacity, 0);
	const valid = draft.rooms.length >= 1;
	const isSelected = (id) => draft.rooms.includes(id);
	const isUnavailable = (id) => unavailable?.has(id) ?? false;
	const removeById = (id) => {
		const idx = draft.rooms.indexOf(id);
		if (idx >= 0) removeRoom(idx);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(StepCard, {
		title: "Choose your room",
		subtitle: `Pick one or more rooms for ${guests} guest${guests > 1 ? "s" : ""}. Capacity selected: ${totalCapacity}. Availability is checked live against current bookings.`,
		children: [
			!checkIn || !checkOut ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mb-4 rounded-xl border border-gold/30 bg-gold/5 p-3 text-xs text-sand-soft/80",
				children: "Pick check-in and check-out dates first to verify room availability."
			}) : null,
			selected.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-6 space-y-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-[10px] uppercase tracking-[0.22em] text-gold",
					children: [
						"Selected (",
						selected.length,
						")"
					]
				}), selected.map((r, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3 rounded-xl border border-gold/40 bg-gold/5 p-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: r.img,
							alt: r.type,
							className: "h-14 w-20 rounded-lg object-cover"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex-1 min-w-0",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "truncate text-sm text-sand-soft",
								children: r.type
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-xs text-muted-foreground",
								children: [
									"$",
									r.price,
									" / night · sleeps ",
									r.capacity
								]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: () => removeRoom(idx),
							"aria-label": "Remove room",
							className: "rounded-full border border-gold/30 p-1.5 text-muted-foreground transition hover:border-gold hover:text-gold",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-3.5 w-3.5" })
						})
					]
				}, `${r.id}-${idx}`))]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-3 text-[10px] uppercase tracking-[0.22em] text-gold",
				children: "All rooms"
			}),
			isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-4",
				children: [
					0,
					1,
					2
				].map((i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-28 animate-pulse rounded-2xl bg-card/60" }, i))
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-4",
				children: rooms.map((r) => {
					const selectedRoom = isSelected(r.id);
					const unavail = isUnavailable(r.id);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: `flex flex-col items-stretch gap-4 rounded-2xl border p-3 transition sm:flex-row sm:items-center ${selectedRoom ? "border-gold bg-gold/5" : unavail ? "border-gold/10 opacity-60" : "border-gold/15 hover:border-gold/40"}`,
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: r.img,
								alt: r.type,
								className: "h-32 w-full rounded-xl object-cover sm:h-24 sm:w-32"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex-1 min-w-0",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex flex-wrap items-center gap-2",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "font-display text-lg text-sand-soft",
												children: r.type
											}),
											selectedRoom && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "inline-flex items-center gap-1 rounded-full bg-gold px-2 py-0.5 text-[10px] font-medium uppercase tracking-wider text-ink",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "h-3 w-3" }), " Selected"]
											}),
											unavail && !selectedRoom && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "inline-flex items-center gap-1 rounded-full border border-destructive/40 px-2 py-0.5 text-[10px] font-medium uppercase tracking-wider text-destructive",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleAlert, { className: "h-3 w-3" }), " Unavailable"]
											})
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs text-muted-foreground",
										children: r.desc
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "mt-1 text-[11px] text-muted-foreground",
										children: ["Sleeps ", r.capacity]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
										to: "/rooms/$id",
										params: { id: r.id },
										search: { from: "booking" },
										className: "mt-2 inline-flex items-center gap-1 text-[11px] text-sand-soft/80 transition hover:text-gold",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, { className: "h-3 w-3" }), " View details"]
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between gap-3 sm:flex-col sm:items-end sm:justify-center",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "text-right",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "font-display text-xl text-gold",
										children: ["$", r.price]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-[10px] uppercase tracking-[0.18em] text-muted-foreground",
										children: "/ night"
									})]
								}), selectedRoom ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: () => removeById(r.id),
									className: "inline-flex items-center gap-1.5 rounded-full border border-gold/40 px-3 py-1.5 text-[11px] font-medium uppercase tracking-wider text-gold transition hover:bg-gold/10",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-3 w-3" }), " Remove"]
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: () => addRoom(r.id),
									disabled: unavail,
									className: "inline-flex items-center gap-1.5 rounded-full bg-gold px-3 py-1.5 text-[11px] font-medium uppercase tracking-wider text-ink transition hover:bg-gold-soft disabled:cursor-not-allowed disabled:opacity-40",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "h-3 w-3" }),
										" ",
										unavail ? "Booked" : "Add room"
									]
								})]
							})
						]
					}, r.id);
				})
			})
		]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StepNav, {
		back: "/booking/guest",
		next: "/booking/dates",
		disabled: !valid
	})] });
}
//#endregion
export { RoomsStep as component };
