import { a as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/booking-flow-D89pOZ68.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var EMPTY = {
	guest: {
		firstName: "",
		lastName: "",
		email: "",
		phone: ""
	},
	rooms: [],
	arrivalTime: "",
	specialRequests: "",
	payment: "property"
};
var KEY = "lavista.draft";
var C = (0, import_react.createContext)(null);
function load() {
	if (typeof window === "undefined") return EMPTY;
	try {
		const raw = window.localStorage.getItem(KEY);
		if (!raw) return EMPTY;
		const parsed = JSON.parse(raw);
		if (Array.isArray(parsed?.rooms) && parsed.rooms.some((r) => typeof r !== "string")) parsed.rooms = parsed.rooms.filter((r) => typeof r === "string");
		return {
			...EMPTY,
			...parsed
		};
	} catch {
		return EMPTY;
	}
}
function BookingFlowProvider({ children }) {
	const [draft, setState] = (0, import_react.useState)(EMPTY);
	const [hydrated, setHydrated] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		setState(load());
		setHydrated(true);
	}, []);
	(0, import_react.useEffect)(() => {
		if (!hydrated || typeof window === "undefined") return;
		window.localStorage.setItem(KEY, JSON.stringify(draft));
	}, [draft, hydrated]);
	const setDraft = (patch) => setState((d) => ({
		...d,
		...patch
	}));
	const setGuest = (patch) => setState((d) => ({
		...d,
		guest: {
			...d.guest,
			...patch
		}
	}));
	const addRoom = (id) => setState((d) => d.rooms.includes(id) ? d : {
		...d,
		rooms: [...d.rooms, id]
	});
	const removeRoom = (idx) => setState((d) => ({
		...d,
		rooms: d.rooms.filter((_, i) => i !== idx)
	}));
	const reset = () => {
		setState(EMPTY);
		if (typeof window !== "undefined") window.localStorage.removeItem(KEY);
	};
	return (0, import_react.createElement)(C.Provider, { value: {
		draft,
		setDraft,
		setGuest,
		addRoom,
		removeRoom,
		reset
	} }, children);
}
function useBookingFlow() {
	const ctx = (0, import_react.useContext)(C);
	if (!ctx) throw new Error("useBookingFlow must be inside BookingFlowProvider");
	return ctx;
}
//#endregion
export { useBookingFlow as n, BookingFlowProvider as t };
