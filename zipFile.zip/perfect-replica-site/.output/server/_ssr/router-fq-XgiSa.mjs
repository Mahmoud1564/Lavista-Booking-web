import { a as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { h as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { s as fetchRooms } from "./booking-api-BfQOc4Uq.mjs";
import { t as QueryClient } from "../_libs/tanstack__query-core.mjs";
import { n as QueryClientProvider } from "../_libs/tanstack__react-query.mjs";
import { D as redirect, c as Outlet, d as createRootRouteWithContext, f as Link, h as useRouter, l as lazyRouteComponent, n as Scripts, r as HeadContent, s as createRouter, u as createFileRoute } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as Route$11 } from "./booking.confirmation._ref-C_0LUDr5.mjs";
import { t as EXPERIENCES } from "./experiences-T1CP3tmx.mjs";
import { t as Route$12 } from "./experiences._slug-DBL3x9Wt.mjs";
import { t as Route$13 } from "./rooms._id-Vi1F-P-l.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/router-fq-XgiSa.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var styles_default = "/assets/styles-BrTjb_cu.css";
function reportLovableError(error, context = {}) {
	if (typeof window === "undefined") return;
	window.__lovableEvents?.captureException?.(error, {
		source: "react_error_boundary",
		route: window.location.pathname,
		...context
	}, {
		mechanism: "react_error_boundary",
		handled: false,
		severity: "error"
	});
}
function NotFoundComponent() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center bg-background px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-md text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-7xl font-bold text-foreground",
					children: "404"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-4 text-xl font-semibold text-foreground",
					children: "Page not found"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "The page you're looking for doesn't exist or has been moved."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-6",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/",
						className: "inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90",
						children: "Go home"
					})
				})
			]
		})
	});
}
function ErrorComponent({ error, reset }) {
	console.error(error);
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		reportLovableError(error, { boundary: "tanstack_root_error_component" });
	}, [error]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center bg-background px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-md text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-xl font-semibold tracking-tight text-foreground",
					children: "This page didn't load"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "Something went wrong on our end. You can try refreshing or head back home."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 flex flex-wrap justify-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => {
							router.invalidate();
							reset();
						},
						className: "inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90",
						children: "Try again"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: "/",
						className: "inline-flex items-center justify-center rounded-md border border-input bg-background px-4 py-2 text-sm font-medium text-foreground transition-colors hover:bg-accent",
						children: "Go home"
					})]
				})
			]
		})
	});
}
var Route$10 = createRootRouteWithContext()({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: "Lavista — Modern Stay near Giza Pyramids" },
			{
				name: "description",
				content: "Lavista is a warm, modern hostel and boutique hotel a short walk from the Pyramids of Giza — cozy rooms, rooftop sunsets, and local Egyptian experiences."
			},
			{
				name: "author",
				content: "Lavista"
			},
			{
				name: "theme-color",
				content: "#0f0a05"
			},
			{
				httpEquiv: "content-language",
				content: "en"
			},
			{
				property: "og:title",
				content: "Lavista — Warm modern stay near the Pyramids"
			},
			{
				property: "og:description",
				content: "Cozy rooms, rooftop sunsets, and local experiences a short walk from the Pyramids of Giza."
			},
			{
				property: "og:type",
				content: "website"
			},
			{
				property: "og:site_name",
				content: "Lavista"
			},
			{
				property: "og:locale",
				content: "en_US"
			},
			{
				name: "twitter:card",
				content: "summary_large_image"
			},
			{
				name: "twitter:site",
				content: "@lavista"
			}
		],
		links: [
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "preconnect",
				href: "https://fonts.googleapis.com"
			},
			{
				rel: "preconnect",
				href: "https://fonts.gstatic.com",
				crossOrigin: ""
			},
			{
				rel: "stylesheet",
				href: "https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,400;9..144,500;9..144,600;9..144,700&family=Inter:wght@300;400;500;600;700&display=swap"
			}
		]
	}),
	shellComponent: RootShell,
	component: RootComponent,
	notFoundComponent: NotFoundComponent,
	errorComponent: ErrorComponent
});
var JSON_LD = JSON.stringify({
	"@context": "https://schema.org",
	"@type": "Organization",
	name: "Lavista",
	url: "https://lavista-pyramids.lovable.app",
	logo: "https://lavista-pyramids.lovable.app/favicon.ico",
	sameAs: ["https://instagram.com"],
	contactPoint: {
		"@type": "ContactPoint",
		telephone: "+20-100-769-5392",
		contactType: "reservations",
		areaServed: "EG",
		availableLanguage: ["English", "Arabic"]
	}
});
function RootShell({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "en",
		suppressHydrationWarning: true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", {
			suppressHydrationWarning: true,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", { children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})] })]
	});
}
function RootComponent() {
	const { queryClient } = Route$10.useRouteContext();
	(0, import_react.useEffect)(() => {
		if (document.getElementById("lavista-json-ld")) return;
		const el = document.createElement("script");
		el.id = "lavista-json-ld";
		el.type = "application/ld+json";
		el.text = JSON_LD;
		document.head.appendChild(el);
		return () => {
			document.getElementById("lavista-json-ld")?.remove();
		};
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QueryClientProvider, {
		client: queryClient,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {})
	});
}
var BASE_URL = "https://lavista-pyramids.lovable.app";
var Route$9 = createFileRoute("/sitemap.xml")({ server: { handlers: { GET: async () => {
	const xml = [
		`<?xml version="1.0" encoding="UTF-8"?>`,
		`<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">`,
		...[
			{
				path: "/",
				changefreq: "weekly",
				priority: "1.0"
			},
			{
				path: "/booking",
				changefreq: "monthly",
				priority: "0.9"
			},
			{
				path: "/manage-booking",
				changefreq: "yearly",
				priority: "0.5"
			},
			...(await fetchRooms().catch(() => [])).map((r) => ({
				path: `/rooms/${r.id}`,
				changefreq: "monthly",
				priority: "0.8"
			})),
			...EXPERIENCES.map((e) => ({
				path: `/experiences/${e.slug}`,
				changefreq: "monthly",
				priority: "0.7"
			}))
		].map((e) => [
			`  <url>`,
			`    <loc>${BASE_URL}${e.path}</loc>`,
			e.changefreq ? `    <changefreq>${e.changefreq}</changefreq>` : null,
			e.priority ? `    <priority>${e.priority}</priority>` : null,
			`  </url>`
		].filter(Boolean).join("\n")),
		`</urlset>`
	].join("\n");
	return new Response(xml, { headers: {
		"Content-Type": "application/xml",
		"Cache-Control": "public, max-age=3600"
	} });
} } } });
var $$splitComponentImporter$7 = () => import("./manage-booking-BSA36JZL.mjs");
var Route$8 = createFileRoute("/manage-booking")({
	head: () => ({
		meta: [
			{ title: "Manage your booking — Lavista" },
			{
				name: "description",
				content: "Look up, review, or cancel your Lavista booking near the Pyramids of Giza."
			},
			{
				property: "og:title",
				content: "Manage your booking — Lavista"
			},
			{
				property: "og:description",
				content: "Look up your Lavista reservation, review the details or cancel."
			},
			{
				property: "og:url",
				content: "https://lavista-pyramids.lovable.app/manage-booking"
			}
		],
		links: [{
			rel: "canonical",
			href: "https://lavista-pyramids.lovable.app/manage-booking"
		}]
	}),
	component: lazyRouteComponent($$splitComponentImporter$7, "component")
});
var $$splitComponentImporter$6 = () => import("./booking-B_mmjDeX.mjs");
var Route$7 = createFileRoute("/booking")({
	head: () => ({
		meta: [
			{ title: "Book your stay — Lavista, Giza" },
			{
				name: "description",
				content: "Reserve your room at Lavista near the Pyramids of Giza in a few simple steps."
			},
			{
				name: "robots",
				content: "noindex,follow"
			}
		],
		links: [{
			rel: "canonical",
			href: "https://lavista-pyramids.lovable.app/booking"
		}]
	}),
	component: lazyRouteComponent($$splitComponentImporter$6, "component")
});
var $$splitComponentImporter$5 = () => import("./routes-CkslDOIJ.mjs");
var Route$6 = createFileRoute("/")({
	head: () => ({
		meta: [
			{ title: "Lavista — Warm modern stay near the Pyramids of Giza" },
			{
				name: "description",
				content: "A stylish, affordable hostel & hotel a short walk from the pyramids. Cozy rooms, rooftop sunsets, local experiences and modern Egyptian hospitality."
			},
			{
				property: "og:title",
				content: "Lavista — Warm modern stay near the Pyramids"
			},
			{
				property: "og:description",
				content: "Cozy rooms, rooftop sunsets, and local experiences a short walk from the Pyramids of Giza."
			},
			{
				property: "og:url",
				content: "https://lavista-pyramids.lovable.app/"
			},
			{
				property: "og:type",
				content: "website"
			},
			{
				property: "og:locale",
				content: "en_US"
			},
			{
				name: "keywords",
				content: "Lavista, hotel near Giza pyramids, hostel Giza, hotel Pyramids of Giza, Egypt boutique hotel, affordable stay Giza, where to stay near the pyramids"
			},
			{
				name: "robots",
				content: "index,follow,max-image-preview:large"
			},
			{
				name: "geo.region",
				content: "EG-GZ"
			},
			{
				name: "geo.placename",
				content: "Giza"
			},
			{
				name: "geo.position",
				content: "29.9773;31.1325"
			},
			{
				name: "ICBM",
				content: "29.9773, 31.1325"
			},
			{
				name: "twitter:card",
				content: "summary_large_image"
			},
			{
				name: "twitter:title",
				content: "Lavista — Warm modern stay near the Pyramids"
			},
			{
				name: "twitter:description",
				content: "Cozy rooms, rooftop sunsets, and local experiences a short walk from the Pyramids of Giza."
			}
		],
		links: [{
			rel: "canonical",
			href: "https://lavista-pyramids.lovable.app/"
		}],
		scripts: [{
			type: "application/ld+json",
			children: JSON.stringify({
				"@context": "https://schema.org",
				"@type": ["Hotel", "LodgingBusiness"],
				"@id": "https://lavista-pyramids.lovable.app/#hotel",
				name: "Lavista",
				description: "Warm, modern hostel and boutique hotel a short walk from the Pyramids of Giza.",
				url: "https://lavista-pyramids.lovable.app/",
				image: "https://lavista-pyramids.lovable.app/og-cover.jpg",
				telephone: "+20-100-769-5392",
				address: {
					"@type": "PostalAddress",
					streetAddress: "Nazlet El-Semman",
					addressLocality: "Giza",
					addressRegion: "Giza Governorate",
					postalCode: "12511",
					addressCountry: "EG"
				},
				geo: {
					"@type": "GeoCoordinates",
					latitude: 29.9773,
					longitude: 31.1325
				},
				areaServed: {
					"@type": "Place",
					name: "Giza, Egypt"
				},
				nearbyAttractions: [{
					"@type": "TouristAttraction",
					name: "Great Pyramid of Giza"
				}, {
					"@type": "TouristAttraction",
					name: "Great Sphinx of Giza"
				}],
				amenityFeature: [
					{
						"@type": "LocationFeatureSpecification",
						name: "Free Wi-Fi",
						value: true
					},
					{
						"@type": "LocationFeatureSpecification",
						name: "Rooftop terrace",
						value: true
					},
					{
						"@type": "LocationFeatureSpecification",
						name: "Air conditioning",
						value: true
					},
					{
						"@type": "LocationFeatureSpecification",
						name: "Airport shuttle",
						value: true
					}
				],
				checkinTime: "14:00",
				checkoutTime: "11:00",
				starRating: {
					"@type": "Rating",
					ratingValue: "4"
				},
				email: "hello@lavista.stay",
				priceRange: "$$",
				currenciesAccepted: "USD, EGP"
			})
		}]
	}),
	component: lazyRouteComponent($$splitComponentImporter$5, "component")
});
var Route$5 = createFileRoute("/booking/")({ beforeLoad: () => {
	throw redirect({ to: "/booking/guest" });
} });
var $$splitComponentImporter$4 = () => import("./booking.rooms-BTuHZmLf.mjs");
var Route$4 = createFileRoute("/booking/rooms")({
	head: () => ({ meta: [{ title: "Choose your rooms — Lavista" }, {
		name: "robots",
		content: "noindex,follow"
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$4, "component")
});
var $$splitComponentImporter$3 = () => import("./booking.payment-CacW0WMK.mjs");
var Route$3 = createFileRoute("/booking/payment")({
	head: () => ({ meta: [{ title: "Payment — Lavista" }, {
		name: "robots",
		content: "noindex,follow"
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$3, "component")
});
var $$splitComponentImporter$2 = () => import("./booking.guest-DNz9Sney.mjs");
var Route$2 = createFileRoute("/booking/guest")({
	head: () => ({ meta: [{ title: "Guest details — Lavista" }, {
		name: "robots",
		content: "noindex,follow"
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$2, "component")
});
var $$splitComponentImporter$1 = () => import("./booking.extras-oEndh21n.mjs");
var Route$1 = createFileRoute("/booking/extras")({
	head: () => ({ meta: [{ title: "Extras — Lavista" }, {
		name: "robots",
		content: "noindex,follow"
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$1, "component")
});
var $$splitComponentImporter = () => import("./booking.dates-Bnpd1K_e.mjs");
var Route = createFileRoute("/booking/dates")({
	head: () => ({ meta: [{ title: "Pick dates — Lavista" }, {
		name: "robots",
		content: "noindex,follow"
	}] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
var SitemapDotxmlRoute = Route$9.update({
	id: "/sitemap.xml",
	path: "/sitemap.xml",
	getParentRoute: () => Route$10
});
var ManageBookingRoute = Route$8.update({
	id: "/manage-booking",
	path: "/manage-booking",
	getParentRoute: () => Route$10
});
var BookingRoute = Route$7.update({
	id: "/booking",
	path: "/booking",
	getParentRoute: () => Route$10
});
var IndexRoute = Route$6.update({
	id: "/",
	path: "/",
	getParentRoute: () => Route$10
});
var BookingIndexRoute = Route$5.update({
	id: "/",
	path: "/",
	getParentRoute: () => BookingRoute
});
var RoomsIdRoute = Route$13.update({
	id: "/rooms/$id",
	path: "/rooms/$id",
	getParentRoute: () => Route$10
});
var ExperiencesSlugRoute = Route$12.update({
	id: "/experiences/$slug",
	path: "/experiences/$slug",
	getParentRoute: () => Route$10
});
var BookingRoomsRoute = Route$4.update({
	id: "/rooms",
	path: "/rooms",
	getParentRoute: () => BookingRoute
});
var BookingPaymentRoute = Route$3.update({
	id: "/payment",
	path: "/payment",
	getParentRoute: () => BookingRoute
});
var BookingGuestRoute = Route$2.update({
	id: "/guest",
	path: "/guest",
	getParentRoute: () => BookingRoute
});
var BookingExtrasRoute = Route$1.update({
	id: "/extras",
	path: "/extras",
	getParentRoute: () => BookingRoute
});
var BookingRouteChildren = {
	BookingDatesRoute: Route.update({
		id: "/dates",
		path: "/dates",
		getParentRoute: () => BookingRoute
	}),
	BookingExtrasRoute,
	BookingGuestRoute,
	BookingPaymentRoute,
	BookingRoomsRoute,
	BookingIndexRoute,
	BookingConfirmationRefRoute: Route$11.update({
		id: "/confirmation/$ref",
		path: "/confirmation/$ref",
		getParentRoute: () => BookingRoute
	})
};
var rootRouteChildren = {
	IndexRoute,
	BookingRoute: BookingRoute._addFileChildren(BookingRouteChildren),
	ManageBookingRoute,
	SitemapDotxmlRoute,
	ExperiencesSlugRoute,
	RoomsIdRoute
};
var routeTree = Route$10._addFileChildren(rootRouteChildren)._addFileTypes();
var getRouter = () => {
	return createRouter({
		routeTree,
		context: { queryClient: new QueryClient() },
		scrollRestoration: true,
		defaultPreloadStaleTime: 0
	});
};
//#endregion
export { getRouter };
