import { h as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { n as useBooking, t as BookingProvider } from "./booking-context-DnMtMm7a.mjs";
import { n as useBookingFlow, t as BookingFlowProvider } from "./booking-flow-D89pOZ68.mjs";
import { n as useRooms } from "./use-rooms-BVO5iBq1.mjs";
import { a as useRouterState, c as Outlet, f as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { E as Check, P as ArrowLeft, l as MapPin } from "../_libs/lucide-react.mjs";
import { t as Footer } from "./Footer-BnjllBH7.mjs";
import { F as differenceInCalendarDays, P as format } from "../_libs/date-fns.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/booking-B_mmjDeX.js
var import_jsx_runtime = require_jsx_runtime();
var STEPS = [
	{
		path: "/booking/guest",
		label: "Guest"
	},
	{
		path: "/booking/rooms",
		label: "Rooms"
	},
	{
		path: "/booking/dates",
		label: "Dates"
	},
	{
		path: "/booking/extras",
		label: "Extras"
	},
	{
		path: "/booking/payment",
		label: "Payment"
	}
];
function BookingLayout() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookingProvider, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookingFlowProvider, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, {}) }) });
}
function Shell() {
	const pathname = useRouterState({ select: (s) => s.location.pathname });
	const isConfirmation = pathname.startsWith("/booking/confirmation");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "min-h-screen bg-background text-foreground",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
				className: "mx-auto flex max-w-6xl items-center justify-between px-6 pt-7 md:pt-10",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/",
					className: "font-display text-xl tracking-tight text-sand-soft",
					children: ["Lavista", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-gold",
						children: "."
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/",
					className: "inline-flex items-center gap-2 text-sm text-sand-soft/80 transition hover:text-gold",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "h-4 w-4" }), " Back to site"]
				})]
			}),
			!isConfirmation && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "mx-auto max-w-6xl px-6 pt-10",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs uppercase tracking-[0.3em] text-gold",
						children: "Booking"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-3 font-display text-4xl text-sand-soft md:text-5xl",
						children: "Reserve your stay"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stepper, { pathname })
				]
			}),
			isConfirmation ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mx-auto grid max-w-6xl gap-10 px-6 py-12 lg:grid-cols-[1.4fr_1fr]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Summary, {})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Footer, {})
		]
	});
}
function Stepper({ pathname }) {
	const currentIdx = Math.max(0, STEPS.findIndex((s) => pathname.startsWith(s.path)));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
		className: "mt-6 flex flex-wrap items-center gap-3 text-xs uppercase tracking-[0.22em]",
		children: STEPS.map((s, i) => {
			const active = i === currentIdx;
			const done = i < currentIdx;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "flex items-center gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: `flex h-7 w-7 items-center justify-center rounded-full border ${done ? "border-gold bg-gold text-ink" : active ? "border-gold text-gold" : "border-gold/20 text-muted-foreground"}`,
						children: done ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "h-3.5 w-3.5" }) : i + 1
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: active || done ? "text-sand-soft" : "text-muted-foreground",
						children: s.label
					}),
					i < STEPS.length - 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-px w-6 bg-gold/20" })
				]
			}, s.path);
		})
	});
}
function Summary() {
	const { checkIn, checkOut, guests } = useBooking();
	const { draft } = useBookingFlow();
	const { data: allRooms = [] } = useRooms();
	const nights = checkIn && checkOut ? Math.max(0, differenceInCalendarDays(checkOut, checkIn)) : 0;
	const rooms = draft.rooms.map((id) => allRooms.find((r) => r.id === id)).filter((r) => Boolean(r));
	const total = rooms.reduce((sum, r) => sum + r.price * Math.max(1, nights), 0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
		className: "h-fit rounded-3xl border border-gold/15 bg-card/60 p-6 md:p-7",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-[10px] uppercase tracking-[0.22em] text-gold",
				children: "Your stay summary"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-3 flex items-center gap-2 text-sm text-sand-soft/85",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "h-3.5 w-3.5 text-gold" }), " Lavista · Nazlet El-Semman, Giza"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-5 space-y-3 text-sm text-sand-soft/85",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						label: "Check-in",
						value: checkIn ? format(checkIn, "EEE, MMM d, yyyy") : "—"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						label: "Check-out",
						value: checkOut ? format(checkOut, "EEE, MMM d, yyyy") : "—"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						label: "Nights",
						value: nights ? String(nights) : "—"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						label: "Guests",
						value: String(guests)
					})
				]
			}),
			rooms.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 border-t border-gold/15 pt-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[10px] uppercase tracking-[0.22em] text-gold",
					children: "Price breakdown"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-3 space-y-2 text-sm",
					children: rooms.map((r, i) => {
						const n = Math.max(1, nights);
						const sub = r.price * n;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex items-baseline justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "min-w-0 truncate text-sand-soft/85",
								children: [r.type, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "ml-1 text-xs text-muted-foreground",
									children: [
										"($",
										r.price,
										" × ",
										n,
										" ",
										n === 1 ? "night" : "nights",
										")"
									]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "shrink-0 text-sand-soft",
								children: ["$", sub]
							})]
						}, `${r.id}-${i}`);
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 rounded-2xl border border-gold/30 bg-gold/10 p-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-baseline justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-xs font-medium uppercase tracking-[0.22em] text-gold",
						children: "Total"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "font-display text-4xl text-sand-soft md:text-5xl",
						children: ["$", total]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-[11px] text-muted-foreground",
					children: "Taxes included · pay on arrival or by card"
				})]
			})
		]
	});
}
function Row({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center justify-between gap-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-muted-foreground",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-right",
			children: value
		})]
	});
}
//#endregion
export { BookingLayout as component };
