//#region node_modules/.nitro/vite/services/ssr/assets/bookings-DozuzODl.js
var KEY = "lavista.bookings";
function loadAll() {
	if (typeof window === "undefined") return [];
	try {
		return JSON.parse(window.localStorage.getItem(KEY) ?? "[]");
	} catch {
		return [];
	}
}
function saveBooking(b) {
	if (typeof window === "undefined") return;
	const all = loadAll();
	all.unshift(b);
	window.localStorage.setItem(KEY, JSON.stringify(all));
}
function findBooking(idOrName, emailOrPhone) {
	const all = loadAll();
	const q1 = idOrName.trim().toLowerCase();
	if (!q1) return void 0;
	const q2 = (emailOrPhone ?? "").trim().toLowerCase();
	const digits = (s) => s.replace(/\D+/g, "");
	const q2Digits = digits(q2);
	return all.find((b) => {
		const fullName = `${b.firstName} ${b.lastName}`.toLowerCase();
		if (!(b.ref.toLowerCase() === q1 || fullName === q1 || fullName.includes(q1))) return false;
		if (!q2) return true;
		const emailMatch = b.email.toLowerCase() === q2;
		const phoneMatch = q2Digits.length > 0 && digits(b.phone) === q2Digits;
		return emailMatch || phoneMatch;
	});
}
function updateBooking(ref, patch) {
	if (typeof window === "undefined") return;
	const all = loadAll().map((b) => b.ref === ref ? {
		...b,
		...patch
	} : b);
	window.localStorage.setItem(KEY, JSON.stringify(all));
}
//#endregion
export { saveBooking as n, updateBooking as r, findBooking as t };
