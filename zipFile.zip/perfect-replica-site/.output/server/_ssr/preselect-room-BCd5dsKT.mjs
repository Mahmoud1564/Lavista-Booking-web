//#region node_modules/.nitro/vite/services/ssr/assets/preselect-room-BCd5dsKT.js
var KEY = "lavista.draft";
function preselectRoom(id) {
	if (typeof window === "undefined") return;
	try {
		const raw = window.localStorage.getItem(KEY);
		const draft = raw ? JSON.parse(raw) : {};
		const rooms = Array.isArray(draft.rooms) ? draft.rooms : [];
		if (!rooms.includes(id)) rooms.push(id);
		window.localStorage.setItem(KEY, JSON.stringify({
			...draft,
			rooms
		}));
	} catch {}
}
//#endregion
export { preselectRoom as t };
