import { a as fetchReviews, i as fetchFaq, l as fetchWebsiteContent, r as fetchExperiences, t as fetchAboutImages } from "./booking-api-BfQOc4Uq.mjs";
import { t as useQuery } from "../_libs/tanstack__react-query.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/use-content-D3tyqQHR.js
function useExperiencesContent() {
	return useQuery({
		queryKey: ["experiences"],
		queryFn: fetchExperiences,
		staleTime: 6e4
	});
}
function useFaqContent() {
	return useQuery({
		queryKey: ["faq"],
		queryFn: fetchFaq,
		staleTime: 6e4
	});
}
function useReviewsContent() {
	return useQuery({
		queryKey: ["reviews"],
		queryFn: fetchReviews,
		staleTime: 6e4
	});
}
function useWebsiteContent() {
	return useQuery({
		queryKey: ["website_content"],
		queryFn: fetchWebsiteContent,
		staleTime: 6e4
	});
}
function useAboutImages() {
	return useQuery({
		queryKey: ["about_images"],
		queryFn: fetchAboutImages,
		staleTime: 6e4
	});
}
//#endregion
export { useWebsiteContent as a, useReviewsContent as i, useExperiencesContent as n, useFaqContent as r, useAboutImages as t };
