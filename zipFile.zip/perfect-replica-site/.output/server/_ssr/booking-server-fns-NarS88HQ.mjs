import { t as createClient } from "../_libs/supabase__supabase-js.mjs";
import { c as createServerFn, i as TSS_SERVER_FUNCTION } from "./esm-I6x-3bX5.mjs";
import processModule from "node:process";
//#region node_modules/.nitro/vite/services/ssr/assets/booking-server-fns-NarS88HQ.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
/**
* Server-side booking functions.
*
* These run exclusively on the server and use the Supabase service-role key,
* which bypasses RLS. This is the correct pattern for a hotel where guests are
* anonymous — the server authorises the write after validating the input, so
* we never need to punch holes in the anon RLS policies for INSERT.
*
* NEVER expose the service-role key to client code — it stays server-side here.
*/
function getAdminClient() {
	const url = processModule.env.SUPABASE_URL ?? processModule.env.VITE_SUPABASE_URL ?? "";
	const key = processModule.env.SUPABASE_SERVICE_ROLE_KEY ?? "";
	if (!url || !key) throw new Error("[booking-server-fns] SUPABASE_URL or SUPABASE_SERVICE_ROLE_KEY is missing.");
	return createClient(url, key, { auth: {
		persistSession: false,
		autoRefreshToken: false
	} });
}
var createGuestFn_createServerFn_handler = createServerRpc({
	id: "6c04165ebeb7dbcb085f6c020bad163d0446ff0695dc1ccefaa35da7f01cae16",
	name: "createGuestFn",
	filename: "src/lib/booking-server-fns.ts"
}, (opts) => createGuestFn.__executeServer(opts));
var createGuestFn = createServerFn({ method: "POST" }).inputValidator((raw) => raw).handler(createGuestFn_createServerFn_handler, async ({ data }) => {
	const { error } = await getAdminClient().from("guests").insert({
		id: data.id,
		name: data.name,
		phone: data.phone,
		email: data.email
	});
	if (error) throw new Error(`createGuest failed: ${error.message} (${error.code})`);
	return { id: data.id };
});
var createBookingFn_createServerFn_handler = createServerRpc({
	id: "f8366f9fe0cdeb3fbc64c197d2506796d98541d104f05f99fdd7de43d032c532",
	name: "createBookingFn",
	filename: "src/lib/booking-server-fns.ts"
}, (opts) => createBookingFn.__executeServer(opts));
var createBookingFn = createServerFn({ method: "POST" }).inputValidator((raw) => raw).handler(createBookingFn_createServerFn_handler, async ({ data }) => {
	const supabase = getAdminClient();
	const payload = {
		id: data.id,
		guest_id: data.guestId,
		check_in: data.checkIn,
		check_out: data.checkOut,
		num_guests: data.numGuests,
		status: "upcoming",
		total_price: data.totalPrice,
		notes: data.notes || null
	};
	if (data.primaryRoomId) payload.room_id = data.primaryRoomId;
	const { error } = await supabase.from("bookings").insert(payload);
	if (error) throw new Error(`createBooking failed: ${error.message} (${error.code})`);
	return { id: data.id };
});
var addBookingRoomFn_createServerFn_handler = createServerRpc({
	id: "688df4ef3ee04c076628739d15f87e185cf06ba50cd1c2b18a247170923c752a",
	name: "addBookingRoomFn",
	filename: "src/lib/booking-server-fns.ts"
}, (opts) => addBookingRoomFn.__executeServer(opts));
var addBookingRoomFn = createServerFn({ method: "POST" }).inputValidator((raw) => raw).handler(addBookingRoomFn_createServerFn_handler, async ({ data }) => {
	const { error } = await getAdminClient().from("booking_rooms").insert({
		booking_id: data.bookingId,
		room_id: data.roomId,
		price_per_night: data.pricePerNight
	});
	if (error) throw new Error(`addBookingRoom failed: ${error.message} (${error.code})`);
	return { ok: true };
});
var fetchBookingByIdFn_createServerFn_handler = createServerRpc({
	id: "1c0d2efabadc575ade07bfcf5a8b59e8c76ce319bc2cd92c6ea5dffc846f0f44",
	name: "fetchBookingByIdFn",
	filename: "src/lib/booking-server-fns.ts"
}, (opts) => fetchBookingByIdFn.__executeServer(opts));
var fetchBookingByIdFn = createServerFn({ method: "GET" }).inputValidator((raw) => raw).handler(fetchBookingByIdFn_createServerFn_handler, async ({ data }) => {
	const { data: row, error } = await getAdminClient().from("bookings").select("id,check_in,check_out,num_guests,status,total_price,notes,created_at,guests(name,phone,email),booking_rooms(room_id,price_per_night,rooms(name,thumbnail_url))").eq("id", data.id).maybeSingle();
	if (error) throw new Error(`fetchBookingById failed: ${error.message}`);
	if (!row) return null;
	const raw = row;
	return {
		id: raw.id,
		check_in: raw.check_in,
		check_out: raw.check_out,
		num_guests: raw.num_guests,
		status: raw.status,
		total_price: raw.total_price,
		notes: raw.notes,
		created_at: raw.created_at,
		guest: raw.guests ?? null,
		rooms: (raw.booking_rooms ?? []).map((br) => ({
			room_id: br.room_id,
			price_per_night: br.price_per_night,
			name: br.rooms?.name ?? "Room",
			thumbnail_url: br.rooms?.thumbnail_url ?? null
		}))
	};
});
//#endregion
export { addBookingRoomFn_createServerFn_handler, createBookingFn_createServerFn_handler, createGuestFn_createServerFn_handler, fetchBookingByIdFn_createServerFn_handler };
