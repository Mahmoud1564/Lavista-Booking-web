import { a as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { h as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { n as useBooking } from "./booking-context-DnMtMm7a.mjs";
import { d as LogOut, f as LogIn, k as CalendarDays, r as Users } from "../_libs/lucide-react.mjs";
import { F as differenceInCalendarDays, L as addDays, P as format } from "../_libs/date-fns.mjs";
import { t as cn } from "./utils-C_uf36nf.mjs";
import { t as Calendar$1 } from "./calendar-DrqWamLw.mjs";
import { n as PopoverContent, r as PopoverTrigger, t as Popover } from "./popover-Cmlz_mk1.mjs";
import { n as StepCard, r as StepNav } from "./booking-flow-ui-Bi1pQ2w4.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/booking.dates-Bnpd1K_e.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function DatesStep() {
	const { checkIn, checkOut, guests, setCheckIn, setCheckOut, setGuests } = useBooking();
	const [openIn, setOpenIn] = (0, import_react.useState)(false);
	const [openOut, setOpenOut] = (0, import_react.useState)(false);
	const nights = checkIn && checkOut ? Math.max(0, differenceInCalendarDays(checkOut, checkIn)) : 0;
	const valid = !!checkIn && !!checkOut && nights > 0 && guests >= 1;
	const handleSetCheckIn = (d) => {
		setCheckIn(d);
		if (d && checkOut && differenceInCalendarDays(checkOut, d) <= 0) setCheckOut(addDays(d, 1));
		setOpenIn(false);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(StepCard, {
		title: "Dates & guests",
		subtitle: "Pick when you'd like to stay and how many people are coming.",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-4 md:grid-cols-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Popover, {
					open: openIn,
					onOpenChange: setOpenIn,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PopoverTrigger, {
						asChild: true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							className: "rounded-2xl border border-gold/20 bg-ink/30 p-4 text-left transition hover:border-gold/40",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "flex items-center gap-2 text-[10px] uppercase tracking-[0.22em] text-gold",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogIn, { className: "h-3.5 w-3.5" }), " Check-in"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 text-sm text-sand-soft",
									children: checkIn ? format(checkIn, "EEE, MMM d, yyyy") : "Pick check-in date"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 text-[11px] text-muted-foreground",
									children: "From 2:00 PM"
								})
							]
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PopoverContent, {
						className: "w-auto bg-card p-0",
						align: "start",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Calendar$1, {
							mode: "single",
							selected: checkIn,
							onSelect: handleSetCheckIn,
							disabled: { before: /* @__PURE__ */ new Date() },
							initialFocus: true,
							className: cn("pointer-events-auto p-3")
						})
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Popover, {
					open: openOut,
					onOpenChange: setOpenOut,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PopoverTrigger, {
						asChild: true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							className: "rounded-2xl border border-gold/20 bg-ink/30 p-4 text-left transition hover:border-gold/40",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "flex items-center gap-2 text-[10px] uppercase tracking-[0.22em] text-gold",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogOut, { className: "h-3.5 w-3.5" }), " Check-out"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 text-sm text-sand-soft",
									children: checkOut ? format(checkOut, "EEE, MMM d, yyyy") : "Pick check-out date"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 text-[11px] text-muted-foreground",
									children: nights > 0 ? `${nights} night${nights > 1 ? "s" : ""}` : "Until 11:00 AM"
								})
							]
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PopoverContent, {
						className: "w-auto bg-card p-0",
						align: "start",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Calendar$1, {
							mode: "single",
							selected: checkOut,
							onSelect: (d) => {
								setCheckOut(d);
								setOpenOut(false);
							},
							disabled: { before: checkIn ? addDays(checkIn, 1) : addDays(/* @__PURE__ */ new Date(), 1) },
							initialFocus: true,
							className: cn("pointer-events-auto p-3")
						})
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-2xl border border-gold/20 bg-ink/30 p-4 md:col-span-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "flex items-center gap-2 text-[10px] uppercase tracking-[0.22em] text-gold",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, { className: "h-3.5 w-3.5" }), " Guests"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 flex items-center gap-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								onClick: () => setGuests(guests - 1),
								disabled: guests <= 1,
								className: "h-9 w-9 rounded-full border border-gold/30 text-gold disabled:opacity-40",
								children: "−"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-lg text-sand-soft",
								children: guests
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								onClick: () => setGuests(guests + 1),
								disabled: guests >= 6,
								className: "h-9 w-9 rounded-full border border-gold/30 text-gold disabled:opacity-40",
								children: "+"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "ml-auto text-xs text-muted-foreground",
								children: "Max 6"
							})
						]
					})]
				})
			]
		}), (!checkIn || !checkOut) && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			onClick: () => {
				const t = /* @__PURE__ */ new Date();
				setCheckIn(t);
				setCheckOut(addDays(t, 2));
			},
			className: "mt-4 inline-flex items-center gap-1.5 text-xs text-gold underline-offset-4 hover:underline",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CalendarDays, { className: "h-3.5 w-3.5" }), " Quick pick: 2-night stay starting today"]
		})]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StepNav, {
		back: "/booking/rooms",
		next: "/booking/extras",
		disabled: !valid
	})] });
}
//#endregion
export { DatesStep as component };
