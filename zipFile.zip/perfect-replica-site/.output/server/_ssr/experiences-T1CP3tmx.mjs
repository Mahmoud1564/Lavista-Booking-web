//#region node_modules/.nitro/vite/services/ssr/assets/experiences-T1CP3tmx.js
var exp_nile_default = "/assets/exp-nile-C4Cft5kn.jpg";
var exp_pyramids_default = "/assets/exp-pyramids-Bxz2FRZX.jpg";
var exp_desert_default = "/assets/exp-desert-DrxEwZjO.jpg";
var exp_food_default = "/assets/exp-food-CFASKmp3.jpg";
var gallery_rooftop_default = "/assets/gallery-rooftop-DMNbtY3B.jpg";
var gallery_cairo_default = "/assets/gallery-cairo-CSLzUgUR.jpg";
var WHATSAPP = "https://wa.me/201007695392";
var EXPERIENCES = [
	{
		slug: "pyramids-tour",
		img: exp_pyramids_default,
		gallery: [
			exp_pyramids_default,
			gallery_cairo_default,
			exp_desert_default
		],
		title: "Pyramids Tour",
		tag: "Half day",
		blurb: "Guided walk through Giza with a local Egyptologist.",
		price: "from $35",
		duration: "4 hours",
		long: "A deep, story-rich walk through the Giza plateau with a licensed Egyptologist. Skip the tourist traps — you'll see the Great Pyramid, the Sphinx, and the quieter corners most visitors miss. Small groups, lots of time for photos.",
		dates: "Daily · 8:00 AM and 2:00 PM departures",
		meeting: "Pickup directly from Lavista lobby. Entry tickets and bottled water included."
	},
	{
		slug: "nile-sunset-cruise",
		img: exp_nile_default,
		gallery: [
			exp_nile_default,
			gallery_cairo_default,
			gallery_rooftop_default
		],
		title: "Nile Sunset Cruise",
		tag: "Evening",
		blurb: "Felucca sail at golden hour with mint tea on board.",
		price: "from $25",
		duration: "2 hours",
		long: "A traditional felucca sailboat ride along the Nile at golden hour. Slow, quiet, mint tea on board, and the best light of the day over the river. Perfect for couples and small groups.",
		dates: "Daily · 5:00 PM (seasonal — adjusts with sunset)",
		meeting: "Private transfer from Lavista to the dock in Giza. Round-trip included."
	},
	{
		slug: "desert-safari",
		img: exp_desert_default,
		gallery: [
			exp_desert_default,
			exp_pyramids_default,
			gallery_cairo_default
		],
		title: "Desert Safari",
		tag: "Full day",
		blurb: "Quad-biking, sandboarding & a Bedouin dinner under the stars.",
		price: "from $60",
		duration: "8 hours",
		long: "Quad-biking across the dunes, sandboarding down the slopes, and a Bedouin dinner under a sky full of stars. Full-day adventure with a guide who actually grew up out there.",
		dates: "Tue · Thu · Sat · 12:00 PM departure",
		meeting: "Pickup from Lavista. 4x4 transfer to the desert camp included."
	},
	{
		slug: "rooftop-nights",
		img: gallery_rooftop_default,
		gallery: [
			gallery_rooftop_default,
			gallery_cairo_default,
			exp_nile_default
		],
		title: "Giza Rooftop Nights",
		tag: "On-site",
		blurb: "Live oud, shisha and skyline views — meet other travelers.",
		price: "free for guests",
		duration: "3–4 hours",
		long: "Our weekly rooftop session — live oud, shisha, mezze plates, and the Giza skyline as a backdrop. The easiest way to meet other travelers staying at Lavista.",
		dates: "Every Thursday & Saturday · 8:00 PM onwards",
		meeting: "On the Lavista rooftop. Just take the lift."
	},
	{
		slug: "local-food-tour",
		img: exp_food_default,
		gallery: [
			exp_food_default,
			gallery_cairo_default,
			gallery_rooftop_default
		],
		title: "Local Food Tour",
		tag: "Evening",
		blurb: "Koshary, ful & street sweets through Giza's local lanes.",
		price: "from $30",
		duration: "3 hours",
		long: "Eat your way through the lanes around Giza with a local host. Koshary, ful, taameya, and the sweet shops only locals know. Come hungry.",
		dates: "Mon · Wed · Fri · 6:00 PM",
		meeting: "Meet in the Lavista lobby. We walk together to the first stop."
	}
];
var getExperience = (slug) => EXPERIENCES.find((e) => e.slug === slug);
//#endregion
export { WHATSAPP as n, getExperience as r, EXPERIENCES as t };
