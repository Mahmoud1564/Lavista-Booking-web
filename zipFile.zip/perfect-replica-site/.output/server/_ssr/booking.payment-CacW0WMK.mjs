import { a as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { h as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { n as useBooking } from "./booking-context-DnMtMm7a.mjs";
import { n as useBookingFlow } from "./booking-flow-D89pOZ68.mjs";
import { c as fetchUnavailableRoomIds, d as generateRef, p as storeRef } from "./booking-api-BfQOc4Uq.mjs";
import { n as useRooms } from "./use-rooms-BVO5iBq1.mjs";
import { p as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { E as Check, S as CircleAlert, j as Building2, v as CreditCard } from "../_libs/lucide-react.mjs";
import { F as differenceInCalendarDays } from "../_libs/date-fns.mjs";
import { n as saveBooking } from "./bookings-DozuzODl.mjs";
import { n as createBookingFn, r as createGuestFn, t as addBookingRoomFn } from "./booking-server-fns-DTgYJGG6.mjs";
import { n as StepCard } from "./booking-flow-ui-Bi1pQ2w4.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/booking.payment-CacW0WMK.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function PaymentStep() {
	const navigate = useNavigate();
	const { checkIn, checkOut, guests, setCheckIn, setCheckOut } = useBooking();
	const { draft, reset } = useBookingFlow();
	const { data: allRooms = [] } = useRooms();
	const [card, setCard] = (0, import_react.useState)({
		number: "",
		name: "",
		exp: "",
		cvc: ""
	});
	const [submitting, setSubmitting] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)(null);
	const nights = checkIn && checkOut ? Math.max(0, differenceInCalendarDays(checkOut, checkIn)) : 0;
	const rooms = draft.rooms.map((id) => allRooms.find((r) => r.id === id)).filter((r) => Boolean(r));
	const total = rooms.reduce((s, r) => s + r.price * Math.max(1, nights), 0);
	const cardComplete = card.number.replace(/\s/g, "").length >= 12 && card.name.trim().length > 0 && card.exp.trim().length >= 4 && card.cvc.trim().length >= 3;
	const canConfirm = nights > 0 && rooms.length > 0 && !!draft.guest.firstName && !!draft.guest.lastName && (draft.payment === "property" || cardComplete);
	const confirm = async () => {
		if (!canConfirm || !checkIn || !checkOut) return;
		setSubmitting(true);
		setError(null);
		try {
			const unavailable = await fetchUnavailableRoomIds(checkIn, checkOut);
			const conflict = rooms.find((r) => unavailable.has(r.id));
			if (conflict) throw new Error(`"${conflict.type}" is no longer available for the selected dates. Please choose a different room.`);
			const fullName = `${draft.guest.firstName} ${draft.guest.lastName}`.trim();
			const guestId = crypto.randomUUID();
			await createGuestFn({ data: {
				id: guestId,
				name: fullName,
				phone: draft.guest.phone,
				email: draft.guest.email || null
			} });
			const notes = [
				draft.arrivalTime ? `Arrival: ${draft.arrivalTime}` : "",
				draft.specialRequests ? `Requests: ${draft.specialRequests}` : "",
				`Payment: ${draft.payment === "property" ? "Pay at property" : "Credit card"}`
			].filter(Boolean).join(" · ");
			const bookingId = crypto.randomUUID();
			await createBookingFn({ data: {
				id: bookingId,
				guestId,
				checkIn: checkIn.toISOString().slice(0, 10),
				checkOut: checkOut.toISOString().slice(0, 10),
				numGuests: guests,
				totalPrice: total,
				notes,
				primaryRoomId: rooms[0].id
			} });
			for (const r of rooms) await addBookingRoomFn({ data: {
				bookingId,
				roomId: r.id,
				pricePerNight: r.price
			} });
			const ref = generateRef();
			storeRef(ref, bookingId);
			const n = Math.max(1, nights);
			saveBooking({
				ref,
				bookingId,
				roomId: rooms[0].id,
				roomType: rooms.map((r) => r.type).join(" + "),
				checkIn: checkIn.toISOString(),
				checkOut: checkOut.toISOString(),
				nights,
				guests,
				total,
				firstName: draft.guest.firstName,
				lastName: draft.guest.lastName,
				email: draft.guest.email,
				phone: draft.guest.phone,
				notes,
				createdAt: (/* @__PURE__ */ new Date()).toISOString(),
				status: "confirmed",
				rooms: rooms.map((r) => ({
					id: r.id,
					type: r.type,
					price: r.price,
					nights: n,
					subtotal: r.price * n
				}))
			});
			reset();
			setCheckIn(void 0);
			setCheckOut(void 0);
			navigate({
				to: "/booking/confirmation/$ref",
				params: { ref }
			});
		} catch (e) {
			let msg;
			if (e && typeof e === "object") {
				const err = e;
				if (err.code || err.details || err.hint) msg = `Booking failed.\n` + (err.code ? `code: ${err.code}\n` : "") + (err.message ? `message: ${err.message}\n` : "") + (err.details ? `details: ${err.details}\n` : "") + (err.hint ? `hint: ${err.hint}` : "");
				else msg = err.message ?? JSON.stringify(e);
			} else msg = String(e);
			console.error("[booking] insert failed:", e);
			setError(msg);
			setSubmitting(false);
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(StepCard, {
		title: "Payment",
		subtitle: "Choose how you'd like to pay. No charge is taken now.",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 md:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PayOption, {
					kind: "property",
					active: draft.payment === "property",
					icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Building2, { className: "h-5 w-5" }),
					title: "Pay at property",
					sub: "Settle the bill on arrival. No prepayment needed."
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PayOption, {
					kind: "card",
					active: draft.payment === "card",
					icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CreditCard, { className: "h-5 w-5" }),
					title: "Credit card",
					sub: "Securely save card details (UI demo, no charge)."
				})]
			}),
			draft.payment === "card" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 grid gap-4 md:grid-cols-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardInput, {
						label: "Card number",
						value: card.number,
						onChange: (v) => setCard({
							...card,
							number: v
						}),
						placeholder: "4242 4242 4242 4242"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardInput, {
						label: "Name on card",
						value: card.name,
						onChange: (v) => setCard({
							...card,
							name: v
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardInput, {
						label: "Expiry (MM/YY)",
						value: card.exp,
						onChange: (v) => setCard({
							...card,
							exp: v
						}),
						placeholder: "12/27"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardInput, {
						label: "CVC",
						value: card.cvc,
						onChange: (v) => setCard({
							...card,
							cvc: v
						}),
						placeholder: "123"
					})
				]
			}),
			error && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 flex items-start gap-2 rounded-xl border border-destructive/40 bg-destructive/10 p-3 text-xs text-destructive",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleAlert, { className: "mt-0.5 h-4 w-4 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "whitespace-pre-wrap",
					children: error
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-6 rounded-xl border border-gold/15 bg-ink/30 p-4 text-xs text-muted-foreground",
				children: "Free cancellation up to 24h before check-in. By confirming, you agree to Lavista's house rules."
			})
		]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mt-8 flex justify-between",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BackLink, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			onClick: confirm,
			disabled: !canConfirm || submitting,
			className: "inline-flex items-center gap-2 rounded-full bg-gold px-6 py-3 text-sm font-medium uppercase tracking-[0.18em] text-ink transition hover:bg-gold-soft disabled:cursor-not-allowed disabled:opacity-50",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "h-4 w-4" }),
				" ",
				submitting ? "Confirming…" : "Confirm booking"
			]
		})]
	})] });
}
function PayOption({ kind, active, icon, title, sub }) {
	const { setDraft } = useBookingFlow();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		onClick: () => setDraft({ payment: kind }),
		className: `flex items-start gap-3 rounded-2xl border p-4 text-left transition ${active ? "border-gold bg-gold/5" : "border-gold/15 hover:border-gold/40"}`,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: `mt-1 ${active ? "text-gold" : "text-sand-soft/70"}`,
				children: icon
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "flex-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "block text-sm text-sand-soft",
					children: title
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "block text-xs text-muted-foreground",
					children: sub
				})]
			}),
			active && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "h-4 w-4 text-gold" })
		]
	});
}
function CardInput({ label, value, onChange, placeholder }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
		className: "text-[10px] uppercase tracking-[0.22em] text-gold",
		children: label
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		value,
		onChange: (e) => onChange(e.target.value),
		placeholder,
		className: "mt-2 w-full rounded-xl border border-gold/20 bg-ink/30 p-3 text-sm text-sand-soft outline-none focus:border-gold"
	})] });
}
function BackLink() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
		href: "/booking/extras",
		className: "inline-flex items-center gap-2 rounded-full border border-gold/30 px-5 py-3 text-xs uppercase tracking-[0.22em] text-sand-soft transition hover:bg-gold/10",
		children: "← Back"
	});
}
//#endregion
export { PaymentStep as component };
