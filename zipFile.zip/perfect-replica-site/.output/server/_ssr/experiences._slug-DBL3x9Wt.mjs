import { l as lazyRouteComponent, u as createFileRoute } from "../_libs/@tanstack/react-router+[...].mjs";
import { r as getExperience } from "./experiences-T1CP3tmx.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/experiences._slug-DBL3x9Wt.js
var $$splitComponentImporter = () => import("./experiences._slug-79ui9BQv.mjs");
var Route = createFileRoute("/experiences/$slug")({
	head: ({ params }) => {
		const exp = getExperience(params.slug);
		const title = exp ? `${exp.title} — Lavista Experiences` : "Experience — Lavista";
		const description = exp?.blurb ?? "Local experiences with Lavista in Giza, Egypt.";
		return { meta: [
			{ title },
			{
				name: "description",
				content: description
			},
			{
				property: "og:title",
				content: title
			},
			{
				property: "og:description",
				content: description
			},
			...exp ? [{
				property: "og:image",
				content: exp.img
			}] : []
		] };
	},
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
