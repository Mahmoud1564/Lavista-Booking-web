import { t as supabase$1 } from "./client-DCt2wTBp.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/booking-api-BfQOc4Uq.js
/** Resolve a stored image reference to a public URL.
*  Accepts either a full http(s) URL or a filename inside the given bucket. */
function publicUrl(bucket, ref) {
	if (!ref) return null;
	if (/^https?:\/\//i.test(ref)) return ref;
	const { data } = supabase$1.storage.from(bucket).getPublicUrl(ref);
	return data?.publicUrl ?? null;
}
var supabase = supabase$1;
var FALLBACK_IMG = "https://images.unsplash.com/photo-1505693416388-ac5ce068fe85?auto=format&fit=crop&w=1600&q=70";
function roomImg(ref) {
	return publicUrl("room-images", ref) ?? FALLBACK_IMG;
}
function mapRoom(r, gallery = []) {
	const thumb = roomImg(r.thumbnail_url);
	const slug = r.name.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
	const gal = gallery.length > 0 ? gallery : [thumb];
	const features = [
		r.beds > 1 ? `${r.beds} beds` : "1 bed",
		`Sleeps ${r.guests}`,
		"Fast Wi-Fi"
	];
	return {
		id: r.id,
		slug,
		type: r.name,
		img: thumb,
		gallery: gal,
		capacity: r.guests,
		beds: r.beds,
		price: Number(r.price),
		desc: r.description ?? "",
		long: r.description ?? "",
		features,
		amenities: [],
		availability: "Live availability — selection is verified against current bookings."
	};
}
async function fetchRooms() {
	const { data, error } = await supabase.from("rooms").select("id,name,description,price,guests,beds,is_active,thumbnail_url").eq("is_active", true).order("price", { ascending: true });
	if (error) throw error;
	return data.map((r) => mapRoom(r));
}
async function fetchRoomGallery(roomId) {
	const { data, error } = await supabase.from("room_images").select("image_url,sort_order,is_thumbnail").eq("room_id", roomId).order("is_thumbnail", { ascending: false }).order("sort_order", { ascending: true });
	if (error) return [];
	return (data ?? []).map((row) => roomImg(row.image_url)).filter(Boolean);
}
async function fetchRoomAmenities(roomId) {
	const { data, error } = await supabase.from("room_amenities").select("amenity").eq("room_id", roomId);
	if (error) return [];
	return (data ?? []).map((r) => r.amenity).filter(Boolean);
}
async function fetchRoom(id) {
	const { data, error } = await supabase.from("rooms").select("id,name,description,price,guests,beds,is_active,thumbnail_url").eq("id", id).maybeSingle();
	if (error) throw error;
	if (!data) return null;
	const [gallery, amenities] = await Promise.all([fetchRoomGallery(id), fetchRoomAmenities(id)]);
	return {
		...mapRoom(data, gallery),
		amenities
	};
}
/** Returns the set of room IDs that are unavailable for the given range. */
async function fetchUnavailableRoomIds(checkIn, checkOut) {
	const ci = checkIn.toISOString().slice(0, 10);
	const co = checkOut.toISOString().slice(0, 10);
	const unavailable = /* @__PURE__ */ new Set();
	const { data: brData, error: brErr } = await supabase.from("booking_rooms").select("room_id, bookings!inner(check_in,check_out,status)").lt("bookings.check_in", co).gt("bookings.check_out", ci).neq("bookings.status", "cancelled");
	if (brErr) throw brErr;
	for (const row of brData ?? []) if (row.room_id) unavailable.add(row.room_id);
	const { data: bData, error: bErr } = await supabase.from("bookings").select("room_id,check_in,check_out,status").lt("check_in", co).gt("check_out", ci).neq("status", "cancelled").not("room_id", "is", null);
	if (bErr) throw bErr;
	for (const row of bData ?? []) if (row.room_id) unavailable.add(row.room_id);
	const { data: blocks, error: blkErr } = await supabase.from("room_blocks").select("room_id,start_date,end_date").lt("start_date", co).gte("end_date", ci);
	if (blkErr) throw blkErr;
	for (const row of blocks ?? []) if (row.room_id) unavailable.add(row.room_id);
	return unavailable;
}
async function fetchBookingById(id) {
	const { data, error } = await supabase.from("bookings").select("id,check_in,check_out,num_guests,status,total_price,notes,created_at, guests(name,phone,email), booking_rooms(room_id,price_per_night, rooms(name,thumbnail_url))").eq("id", id).maybeSingle();
	if (error) throw error;
	if (!data) return null;
	const d = data;
	return {
		id: d.id,
		check_in: d.check_in,
		check_out: d.check_out,
		num_guests: d.num_guests,
		status: d.status,
		total_price: Number(d.total_price),
		notes: d.notes,
		created_at: d.created_at,
		guest: d.guests,
		rooms: (d.booking_rooms ?? []).map((r) => ({
			room_id: r.room_id,
			price_per_night: r.price_per_night != null ? Number(r.price_per_night) : null,
			name: r.rooms?.name ?? "Room",
			thumbnail_url: r.rooms?.thumbnail_url ?? null
		}))
	};
}
/**
* Search for a booking by booking ID (UUID or short LV- ref) OR
* by guest first + last name. Returns the first match, most recent first.
*/
async function findBookingByGuest(nameOrId, extra = {}) {
	const raw = (nameOrId ?? "").trim();
	const firstName = (extra.firstName ?? "").trim();
	const lastName = (extra.lastName ?? "").trim();
	const digits = (extra.phone ?? "").replace(/\D+/g, "");
	if (/^[0-9a-f-]{36}$/i.test(raw)) {
		if (await fetchBookingById(raw)) return {
			ref: raw,
			bookingId: raw
		};
	}
	if (/^lv-/i.test(raw)) {
		const mapped = resolveRef(raw.toUpperCase());
		if (mapped) return {
			ref: raw.toUpperCase(),
			bookingId: mapped
		};
	}
	const nameQuery = [firstName, lastName].filter(Boolean).join(" ").trim() || raw;
	if (!nameQuery && !digits) return null;
	let query = supabase.from("guests").select("id,name,phone").limit(100);
	if (nameQuery) {
		const parts = nameQuery.split(/\s+/).filter(Boolean);
		if (parts.length >= 2) for (const p of parts) query = query.ilike("name", `%${p}%`);
		else query = query.ilike("name", `%${parts[0]}%`);
	}
	const { data: guests } = await query;
	const candidates = (guests ?? []).filter((g) => {
		if (!digits) return true;
		return (g.phone ?? "").replace(/\D+/g, "").endsWith(digits.slice(-9));
	});
	if (candidates.length === 0) return null;
	const { data: bookings } = await supabase.from("bookings").select("id,created_at,guest_id").in("guest_id", candidates.map((g) => g.id)).order("created_at", { ascending: false }).limit(1);
	const row = (bookings ?? [])[0];
	if (!row) return null;
	return {
		ref: row.id,
		bookingId: row.id
	};
}
/** Stores ref↔bookingId mapping so the confirmation route can look up by short ref. */
var REF_KEY = "lavista.bookingRefs";
function generateRef() {
	return "LV-" + Math.random().toString(36).slice(2, 8).toUpperCase();
}
function storeRef(ref, bookingId) {
	if (typeof window === "undefined") return;
	try {
		const raw = window.localStorage.getItem(REF_KEY);
		const map = raw ? JSON.parse(raw) : {};
		map[ref] = bookingId;
		window.localStorage.setItem(REF_KEY, JSON.stringify(map));
	} catch {}
}
function resolveRef(ref) {
	if (typeof window === "undefined") return null;
	try {
		const raw = window.localStorage.getItem(REF_KEY);
		if (!raw) return null;
		return JSON.parse(raw)[ref] ?? null;
	} catch {
		return null;
	}
}
function expSlug(title) {
	return title.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
}
async function fetchExperienceGallery(id) {
	const { data } = await supabase.from("experience_images").select("image_url,sort_order").eq("experience_id", id).order("sort_order", {
		ascending: true,
		nullsFirst: false
	});
	return (data ?? []).map((r) => publicUrl("experience-images", r.image_url)).filter((u) => !!u);
}
async function fetchExperiences() {
	const { data, error } = await supabase.from("experiences").select("id,title,description,duration,thumbnail_url,meeting_point,pickup_info,is_active").eq("is_active", true).order("created_at", { ascending: true });
	if (error) throw error;
	const rows = data ?? [];
	const galleries = await Promise.all(rows.map((r) => fetchExperienceGallery(r.id).catch(() => [])));
	return rows.map((e, i) => {
		const img = publicUrl("experience-images", e.thumbnail_url) ?? galleries[i][0] ?? "";
		const gallery = galleries[i].length > 0 ? galleries[i] : img ? [img] : [];
		return {
			id: e.id,
			slug: expSlug(e.title),
			title: e.title,
			blurb: e.description ?? "",
			long: e.description ?? "",
			tag: e.duration ?? "Experience",
			duration: e.duration ?? "",
			meeting: [e.meeting_point, e.pickup_info].filter(Boolean).join(" · "),
			dates: "",
			img,
			gallery
		};
	});
}
async function fetchFaq() {
	const { data, error } = await supabase.from("faq").select("id,question,answer,sort_order").order("sort_order", {
		ascending: true,
		nullsFirst: false
	});
	if (error) throw error;
	return (data ?? []).map((f) => ({
		q: f.question,
		a: f.answer
	}));
}
async function fetchReviews() {
	const { data, error } = await supabase.from("reviews").select("id,guest_name,rating,review_text,image_url,created_at").order("created_at", { ascending: false }).limit(12);
	if (error) throw error;
	return (data ?? []).map((r) => ({
		name: r.guest_name,
		text: r.review_text,
		rating: r.rating ?? 5,
		avatar: publicUrl("review-images", r.image_url) ?? "",
		from: ""
	}));
}
async function fetchWebsiteContent() {
	const { data, error } = await supabase.from("website_content").select("key,value");
	if (error) return {};
	const map = {};
	for (const row of data ?? []) map[row.key] = row.value;
	return map;
}
async function fetchAboutImages() {
	const { data, error } = await supabase.from("about_images").select("image_url,sort_order").order("sort_order", {
		ascending: true,
		nullsFirst: false
	});
	if (error) return [];
	return (data ?? []).map((r) => publicUrl("about-images", r.image_url)).filter((u) => !!u);
}
//#endregion
export { fetchReviews as a, fetchUnavailableRoomIds as c, generateRef as d, resolveRef as f, fetchFaq as i, fetchWebsiteContent as l, fetchBookingById as n, fetchRoom as o, storeRef as p, fetchExperiences as r, fetchRooms as s, fetchAboutImages as t, findBookingByGuest as u };
