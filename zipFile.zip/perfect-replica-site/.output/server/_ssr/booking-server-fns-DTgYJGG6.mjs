import { c as createServerFn, i as TSS_SERVER_FUNCTION } from "./esm-I6x-3bX5.mjs";
import { t as getServerFnById } from "../__23tanstack-start-server-fn-resolver-CecYBZW6.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/booking-server-fns-DTgYJGG6.js
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
/**
* Server-side booking functions.
*
* These run exclusively on the server and use the Supabase service-role key,
* which bypasses RLS. This is the correct pattern for a hotel where guests are
* anonymous — the server authorises the write after validating the input, so
* we never need to punch holes in the anon RLS policies for INSERT.
*
* NEVER expose the service-role key to client code — it stays server-side here.
*/
/** Create a guest record (server-side, service role). */
var createGuestFn = createServerFn({ method: "POST" }).inputValidator((raw) => raw).handler(createSsrRpc("6c04165ebeb7dbcb085f6c020bad163d0446ff0695dc1ccefaa35da7f01cae16"));
/** Create a booking record (server-side, service role). */
var createBookingFn = createServerFn({ method: "POST" }).inputValidator((raw) => raw).handler(createSsrRpc("f8366f9fe0cdeb3fbc64c197d2506796d98541d104f05f99fdd7de43d032c532"));
/** Link a room to a booking (server-side, service role). */
var addBookingRoomFn = createServerFn({ method: "POST" }).inputValidator((raw) => raw).handler(createSsrRpc("688df4ef3ee04c076628739d15f87e185cf06ba50cd1c2b18a247170923c752a"));
/** Fetch a full booking by UUID — server-side so it bypasses anon SELECT RLS.
*  Returns a FullBooking (same shape as booking-api.fetchBookingById) or null.
*/
var fetchBookingByIdFn = createServerFn({ method: "GET" }).inputValidator((raw) => raw).handler(createSsrRpc("1c0d2efabadc575ade07bfcf5a8b59e8c76ce319bc2cd92c6ea5dffc846f0f44"));
//#endregion
export { fetchBookingByIdFn as i, createBookingFn as n, createGuestFn as r, addBookingRoomFn as t };
