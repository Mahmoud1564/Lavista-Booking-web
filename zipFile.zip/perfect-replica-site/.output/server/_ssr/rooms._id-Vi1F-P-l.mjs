import { l as lazyRouteComponent, u as createFileRoute } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/rooms._id-Vi1F-P-l.js
var $$splitComponentImporter = () => import("./rooms._id-mfZWoWrZ.mjs");
var Route = createFileRoute("/rooms/$id")({
	validateSearch: (search) => ({ from: typeof search.from === "string" ? search.from : void 0 }),
	head: ({ params }) => {
		return { meta: [
			{ title: `Room — Lavista, Giza` },
			{
				name: "description",
				content: "Lavista room near the Pyramids of Giza."
			},
			{
				name: "robots",
				content: "noindex,follow"
			}
		] };
	},
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
