import { a as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { h as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { n as fetchBookingById, u as findBookingByGuest } from "./booking-api-BfQOc4Uq.mjs";
import { f as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { P as ArrowLeft, _ as Download, a as Search, c as MessageCircle, p as LoaderCircle, x as CircleX } from "../_libs/lucide-react.mjs";
import { t as Footer } from "./Footer-BnjllBH7.mjs";
import { F as differenceInCalendarDays, P as format } from "../_libs/date-fns.mjs";
import { r as updateBooking, t as findBooking } from "./bookings-DozuzODl.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/manage-booking-BSA36JZL.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function viewFromStored(b) {
	return {
		ref: b.ref,
		bookingId: b.bookingId,
		firstName: b.firstName,
		lastName: b.lastName,
		email: b.email,
		phone: b.phone,
		guests: b.guests,
		checkIn: b.checkIn,
		checkOut: b.checkOut,
		nights: b.nights,
		total: b.total,
		roomType: b.roomType,
		status: b.status
	};
}
function viewFromRemote(ref, b) {
	const ci = new Date(b.check_in);
	const co = new Date(b.check_out);
	const nights = Math.max(1, differenceInCalendarDays(co, ci));
	const [fn, ...rest] = (b.guest?.name ?? "").split(" ");
	return {
		ref,
		bookingId: b.id,
		firstName: fn ?? "",
		lastName: rest.join(" "),
		email: b.guest?.email ?? "",
		phone: b.guest?.phone ?? "",
		guests: b.num_guests,
		checkIn: b.check_in,
		checkOut: b.check_out,
		nights,
		total: b.total_price,
		roomType: b.rooms.map((r) => r.name).join(" + ") || "Room",
		status: b.status ?? "confirmed"
	};
}
function Manage() {
	const [mode, setMode] = (0, import_react.useState)("id");
	const [bookingId, setBookingId] = (0, import_react.useState)("");
	const [firstName, setFirstName] = (0, import_react.useState)("");
	const [lastName, setLastName] = (0, import_react.useState)("");
	const [view, setView] = (0, import_react.useState)(null);
	const [loading, setLoading] = (0, import_react.useState)(false);
	const [searched, setSearched] = (0, import_react.useState)(false);
	const [errMsg, setErrMsg] = (0, import_react.useState)(null);
	const lookup = async (e) => {
		e.preventDefault();
		setLoading(true);
		setSearched(true);
		setErrMsg(null);
		setView(null);
		await new Promise((r) => setTimeout(r, 350));
		try {
			let found = null;
			if (mode === "id") {
				const q = bookingId.trim();
				const local = findBooking(q);
				if (local) found = viewFromStored(local);
				if (!found) {
					const remote = await findBookingByGuest(q);
					if (remote) {
						const full = await fetchBookingById(remote.bookingId);
						if (full) found = viewFromRemote(remote.ref, full);
					}
				}
			} else {
				const local = findBooking(`${firstName.trim()} ${lastName.trim()}`.trim());
				if (local) found = viewFromStored(local);
				if (!found) {
					const remote = await findBookingByGuest("", {
						firstName,
						lastName
					});
					if (remote) {
						const full2 = await fetchBookingById(remote.bookingId);
						if (full2) found = viewFromRemote(remote.ref, full2);
					}
				}
			}
			if (!found) setErrMsg(mode === "id" ? "No booking matched that ID. Double-check and try again, or search by name." : "No booking matched that name. Double-check the spelling, or search by booking ID.");
			setView(found);
		} catch (err) {
			console.error("[manage-booking] lookup error", err);
			setErrMsg("Something went wrong while searching. Please try again.");
		} finally {
			setLoading(false);
		}
	};
	const cancel = async () => {
		if (!view) return;
		if (!confirm("Cancel this booking? This cannot be undone.")) return;
		setLoading(true);
		await new Promise((r) => setTimeout(r, 300));
		updateBooking(view.ref, { status: "cancelled" });
		setView({
			...view,
			status: "cancelled"
		});
		setLoading(false);
	};
	const download = () => {
		if (!view) return;
		const W = 1200;
		const H = 1500;
		const canvas = document.createElement("canvas");
		canvas.width = W;
		canvas.height = H;
		const ctx = canvas.getContext("2d");
		if (!ctx) return;
		const grad = ctx.createLinearGradient(0, 0, 0, H);
		grad.addColorStop(0, "#140C04");
		grad.addColorStop(1, "#0B0703");
		ctx.fillStyle = grad;
		ctx.fillRect(0, 0, W, H);
		ctx.fillStyle = "#D4A550";
		ctx.fillRect(80, 200, 120, 4);
		ctx.fillStyle = "#F5EBD8";
		ctx.font = "600 64px serif";
		ctx.fillText("Lavista.", 80, 160);
		ctx.fillStyle = "#D4A550";
		ctx.font = "500 22px sans-serif";
		ctx.fillText(view.status === "cancelled" ? "BOOKING CANCELLED" : "BOOKING CONFIRMED", 80, 260);
		ctx.fillStyle = "#F5EBD8";
		ctx.font = "600 56px serif";
		ctx.fillText(`Reference  ${view.ref}`, 80, 330);
		ctx.fillStyle = "rgba(212,165,80,0.2)";
		ctx.fillRect(80, 380, W - 160, 1);
		const rows = [
			["Guest", `${view.firstName} ${view.lastName}`.trim() || "—"],
			["Phone", view.phone || "—"],
			["Email", view.email || "—"],
			["Room", view.roomType],
			["Guests", String(view.guests)],
			["Check-in", format(new Date(view.checkIn), "EEE, MMM d, yyyy")],
			["Check-out", format(new Date(view.checkOut), "EEE, MMM d, yyyy")],
			["Nights", String(view.nights)],
			["Total", `$${view.total}`]
		];
		let y = 440;
		rows.forEach(([k, v]) => {
			ctx.fillStyle = "#D4A550";
			ctx.font = "500 20px sans-serif";
			ctx.fillText(k.toUpperCase(), 80, y);
			ctx.fillStyle = "#F5EBD8";
			ctx.font = "400 32px sans-serif";
			ctx.fillText(v, 80, y + 44);
			y += 96;
		});
		ctx.fillStyle = "rgba(212,165,80,0.2)";
		ctx.fillRect(80, H - 200, W - 160, 1);
		ctx.fillStyle = "#A89A82";
		ctx.font = "400 22px sans-serif";
		ctx.fillText("Lavista · Nazlet El-Semman, Giza, Egypt", 80, H - 140);
		ctx.fillText("WhatsApp: +20 100 769 5392", 80, H - 100);
		canvas.toBlob((blob) => {
			if (!blob) return;
			const url = URL.createObjectURL(blob);
			const a = document.createElement("a");
			a.href = url;
			a.download = `lavista-${view.ref}.png`;
			a.click();
			URL.revokeObjectURL(url);
		}, "image/png");
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "min-h-screen bg-background text-foreground",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
				className: "mx-auto flex max-w-4xl items-center justify-between px-6 pt-7 md:pt-10",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/",
					className: "font-display text-xl tracking-tight text-sand-soft",
					children: ["Lavista", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-gold",
						children: "."
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/",
					className: "inline-flex items-center gap-2 text-sm text-sand-soft/80 transition hover:text-gold",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "h-4 w-4" }), " Home"]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mx-auto max-w-3xl px-6 py-16",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs uppercase tracking-[0.3em] text-gold",
						children: "Manage booking"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-3 font-display text-4xl text-sand-soft md:text-5xl",
						children: "Look up your stay"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 max-w-xl text-sm text-muted-foreground",
						children: "Search by your booking ID or by your first and last name to review, download, or cancel your reservation."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-8 inline-flex rounded-full border border-gold/20 bg-card/60 p-1",
						children: ["id", "name"].map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: () => {
								setMode(m);
								setSearched(false);
								setView(null);
								setErrMsg(null);
							},
							className: `rounded-full px-4 py-2 text-xs uppercase tracking-[0.2em] transition ${mode === m ? "bg-gold text-ink" : "text-sand-soft/80 hover:text-gold"}`,
							children: m === "id" ? "By booking ID" : "By name"
						}, m))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
						onSubmit: lookup,
						className: "mt-4 grid gap-4 rounded-3xl border border-gold/15 bg-card/60 p-6 md:grid-cols-[1fr_auto]",
						children: [mode === "id" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "text-[10px] uppercase tracking-[0.22em] text-gold",
							children: "Booking ID"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							value: bookingId,
							onChange: (e) => setBookingId(e.target.value),
							placeholder: "e.g. LV-ABC123 or the full UUID",
							required: true,
							className: "mt-2 w-full rounded-xl border border-gold/20 bg-ink/30 p-3 text-sm text-sand-soft outline-none focus:border-gold"
						})] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-3 sm:grid-cols-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "text-[10px] uppercase tracking-[0.22em] text-gold",
								children: "First name"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								value: firstName,
								onChange: (e) => setFirstName(e.target.value),
								placeholder: "Jane",
								required: true,
								className: "mt-2 w-full rounded-xl border border-gold/20 bg-ink/30 p-3 text-sm text-sand-soft outline-none focus:border-gold"
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "text-[10px] uppercase tracking-[0.22em] text-gold",
								children: "Last name"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								value: lastName,
								onChange: (e) => setLastName(e.target.value),
								placeholder: "Doe",
								required: true,
								className: "mt-2 w-full rounded-xl border border-gold/20 bg-ink/30 p-3 text-sm text-sand-soft outline-none focus:border-gold"
							})] })]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "submit",
							disabled: loading,
							className: "inline-flex items-center justify-center gap-2 self-end rounded-xl bg-gold px-5 py-3 text-sm font-medium text-ink transition hover:bg-gold-soft disabled:opacity-70",
							children: [loading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "h-4 w-4 animate-spin" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "h-4 w-4" }), loading ? "Searching…" : "Find"]
						})]
					}),
					loading && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-8 flex items-center gap-3 rounded-2xl border border-gold/15 bg-card/60 p-6 text-sm text-sand-soft/80",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "h-4 w-4 animate-spin text-gold" }), "Searching your reservation…"]
					}),
					!loading && searched && !view && errMsg && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-8 rounded-2xl border border-gold/15 bg-card/60 p-6 text-sm text-muted-foreground",
						children: errMsg
					}),
					!loading && view && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-8 rounded-3xl border border-gold/15 bg-card/60 p-6 md:p-8",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-baseline justify-between",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[10px] uppercase tracking-[0.22em] text-gold",
									children: "Reference"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-display text-2xl text-sand-soft",
									children: view.ref
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: `rounded-full px-3 py-1 text-[10px] uppercase tracking-[0.22em] ${view.status === "cancelled" ? "bg-destructive/15 text-destructive" : "bg-gold/15 text-gold"}`,
									children: view.status
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
								className: "mt-6 grid gap-3 text-sm md:grid-cols-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
										label: "Guest",
										value: `${view.firstName} ${view.lastName}`.trim() || "—"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
										label: "Email",
										value: view.email || "—"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
										label: "Phone",
										value: view.phone || "—"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
										label: "Room",
										value: view.roomType
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
										label: "Guests",
										value: String(view.guests)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
										label: "Check-in",
										value: format(new Date(view.checkIn), "EEE, MMM d, yyyy")
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
										label: "Check-out",
										value: format(new Date(view.checkOut), "EEE, MMM d, yyyy")
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
										label: "Nights",
										value: String(view.nights)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
										label: "Total",
										value: `$${view.total}`
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-8 flex flex-wrap gap-3",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										onClick: download,
										className: "inline-flex items-center gap-2 rounded-full bg-gold px-5 py-3 text-xs font-medium uppercase tracking-[0.2em] text-ink transition hover:bg-gold-soft",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "h-4 w-4" }), " Download as PNG"]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
										href: "https://wa.me/201007695392",
										target: "_blank",
										rel: "noreferrer",
										className: "inline-flex items-center gap-2 rounded-full border border-gold/30 px-5 py-3 text-xs uppercase tracking-[0.22em] text-sand-soft transition hover:bg-gold/10",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageCircle, { className: "h-4 w-4" }), " Contact"]
									}),
									view.status !== "cancelled" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										onClick: cancel,
										className: "inline-flex items-center gap-2 rounded-full border border-destructive/40 px-5 py-3 text-xs uppercase tracking-[0.22em] text-destructive transition hover:bg-destructive/10",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleX, { className: "h-4 w-4" }), " Cancel booking"]
									})
								]
							})
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Footer, {})
		]
	});
}
function Row({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-xl border border-gold/10 bg-ink/30 p-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-[10px] uppercase tracking-[0.22em] text-gold",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 text-sand-soft",
			children: value
		})]
	});
}
//#endregion
export { Manage as component };
