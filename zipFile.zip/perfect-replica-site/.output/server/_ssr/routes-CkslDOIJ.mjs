import { a as __toESM } from "../_runtime.mjs";
import { n as AnimatePresence, t as motion } from "../_libs/framer-motion.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { a as Trigger2, h as require_jsx_runtime, i as Root2, n as Header, r as Item, t as Content2 } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { n as useBooking, t as BookingProvider } from "./booking-context-DnMtMm7a.mjs";
import { n as useRooms, r as useUnavailableRooms } from "./use-rooms-BVO5iBq1.mjs";
import { f as Link, i as useLocation, p as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { A as CalendarCheck, C as ChevronRight, D as Car, M as ArrowUpRight, N as ArrowRight, O as Calendar, T as ChevronDown, a as Search, c as MessageCircle, i as Star, l as MapPin, n as Wallet, r as Users, s as Plane, w as ChevronLeft, y as Coffee } from "../_libs/lucide-react.mjs";
import { t as Footer } from "./Footer-BnjllBH7.mjs";
import { F as differenceInCalendarDays, I as startOfDay, L as addDays, P as format } from "../_libs/date-fns.mjs";
import { t as cn } from "./utils-C_uf36nf.mjs";
import { t as Calendar$1 } from "./calendar-DrqWamLw.mjs";
import { n as PopoverContent, r as PopoverTrigger, t as Popover } from "./popover-Cmlz_mk1.mjs";
import { n as WHATSAPP, t as EXPERIENCES } from "./experiences-T1CP3tmx.mjs";
import { a as useWebsiteContent, i as useReviewsContent, n as useExperiencesContent, r as useFaqContent, t as useAboutImages } from "./use-content-D3tyqQHR.mjs";
import { a as CarouselPrevious, i as CarouselNext, n as CarouselContent, r as CarouselItem, t as Carousel } from "./carousel-mra82WDg.mjs";
import { t as preselectRoom } from "./preselect-room-BCd5dsKT.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-CkslDOIJ.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var hero_pyramids_default = "/assets/hero-pyramids-DADob_Ms.jpg";
function Field({ label, value, icon, onClick, asChild }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(asChild ? "div" : "button", {
		type: asChild ? void 0 : "button",
		onClick,
		className: "group flex w-full min-w-0 items-center gap-3 rounded-2xl px-5 py-3 text-left transition hover:bg-gold/10 active:bg-gold/15 md:rounded-full",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "shrink-0 text-gold transition group-hover:scale-110",
			children: icon
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "flex min-w-0 flex-col",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-[10px] font-medium uppercase tracking-[0.18em] text-sand-soft/60",
				children: label
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "truncate whitespace-nowrap text-sm text-sand-soft",
				children: value
			})]
		})]
	});
}
var sharedCalendarClassNames = { today: "rounded-md border border-gold/60 bg-transparent text-sand-soft data-[selected=true]:border-transparent" };
var sharedModifiersClassNames = {
	rangeStart: "bg-gold text-ink rounded-l-md [&_button]:bg-gold [&_button]:text-ink [&_button]:hover:bg-gold",
	rangeEnd: "bg-gold text-ink rounded-r-md [&_button]:bg-gold [&_button]:text-ink [&_button]:hover:bg-gold",
	rangeMiddle: "bg-gold/25 text-sand-soft rounded-none [&_button]:bg-transparent [&_button]:text-sand-soft [&_button]:hover:bg-gold/30",
	selectedSingle: "bg-gold text-ink rounded-md [&_button]:bg-gold [&_button]:text-ink [&_button]:hover:bg-gold"
};
function BookingBar({ onSearch }) {
	const { checkIn, checkOut, guests, setCheckIn, setCheckOut, setGuests } = useBooking();
	const [openIn, setOpenIn] = (0, import_react.useState)(false);
	const [openOut, setOpenOut] = (0, import_react.useState)(false);
	const [openGuests, setOpenGuests] = (0, import_react.useState)(false);
	const today = startOfDay(/* @__PURE__ */ new Date());
	const checkInLabel = checkIn ? format(checkIn, "EEE, MMM d") : "Add date";
	const checkOutLabel = checkOut ? format(checkOut, "EEE, MMM d") : "Add date";
	const atMax = guests >= 6;
	const atMin = guests <= 1;
	const rangeModifiers = (() => {
		if (checkIn && checkOut) return {
			rangeStart: checkIn,
			rangeEnd: checkOut,
			rangeMiddle: {
				after: checkIn,
				before: checkOut
			}
		};
		if (checkIn) return { selectedSingle: checkIn };
		if (checkOut) return { selectedSingle: checkOut };
		return {};
	})();
	const NightsHeader = () => {
		const n = checkIn && checkOut ? Math.max(0, Math.round((+checkOut - +checkIn) / 864e5)) : 0;
		return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center justify-between border-b border-gold/15 px-4 pb-3 pt-3 text-xs",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "uppercase tracking-[0.22em] text-gold",
				children: "Your stay"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-sand-soft",
				children: n > 0 ? `${n} night${n > 1 ? "s" : ""}` : "Pick check-in & check-out"
			})]
		});
	};
	const handleSearch = () => {
		onSearch?.();
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "mx-auto w-full max-w-[1200px]",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "glass flex w-full flex-col items-stretch gap-1 rounded-3xl p-2 shadow-2xl shadow-black/40 md:flex-row md:flex-nowrap md:items-center md:rounded-full md:p-1.5",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Popover, {
					open: openIn,
					onOpenChange: setOpenIn,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PopoverTrigger, {
						asChild: true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "min-w-0 flex-1 cursor-pointer",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								asChild: true,
								label: "Check in",
								value: checkInLabel,
								icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Calendar, { className: "h-4 w-4" })
							})
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PopoverContent, {
						className: "w-auto bg-card p-0",
						align: "start",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NightsHeader, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Calendar$1, {
							mode: "single",
							numberOfMonths: 2,
							selected: checkIn,
							onSelect: (d) => {
								if (!d) return;
								setCheckIn(d);
								if (checkOut && d >= checkOut) setCheckOut(void 0);
								setOpenIn(false);
							},
							disabled: { before: today },
							modifiers: rangeModifiers,
							modifiersClassNames: sharedModifiersClassNames,
							initialFocus: true,
							classNames: sharedCalendarClassNames,
							className: cn("pointer-events-auto p-3")
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "hidden h-8 w-px bg-gold/20 md:block" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Popover, {
					open: openOut,
					onOpenChange: setOpenOut,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PopoverTrigger, {
						asChild: true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "min-w-0 flex-1 cursor-pointer",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								asChild: true,
								label: "Check out",
								value: checkOutLabel,
								icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Calendar, { className: "h-4 w-4" })
							})
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PopoverContent, {
						className: "w-auto bg-card p-0",
						align: "start",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NightsHeader, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Calendar$1, {
							mode: "single",
							numberOfMonths: 2,
							selected: checkOut,
							onSelect: (d) => {
								if (!d) return;
								setCheckOut(d);
								setOpenOut(false);
							},
							disabled: { before: checkIn ? addDays(checkIn, 1) : addDays(today, 1) },
							modifiers: rangeModifiers,
							modifiersClassNames: sharedModifiersClassNames,
							initialFocus: true,
							classNames: sharedCalendarClassNames,
							className: cn("pointer-events-auto p-3")
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "hidden h-8 w-px bg-gold/20 md:block" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Popover, {
					open: openGuests,
					onOpenChange: setOpenGuests,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PopoverTrigger, {
						asChild: true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "min-w-0 flex-1 cursor-pointer md:max-w-[180px]",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								asChild: true,
								label: "Guests",
								value: `${guests} guest${guests > 1 ? "s" : ""}`,
								icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, { className: "h-4 w-4" })
							})
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PopoverContent, {
						className: "w-64 bg-card p-4",
						align: "end",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm font-medium text-sand-soft",
								children: "Guests"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-muted-foreground",
								children: "Up to 6 per booking"
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-3",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										onClick: () => setGuests(Math.max(1, guests - 1)),
										disabled: atMin,
										"aria-label": "Decrease guests",
										className: "flex h-8 w-8 items-center justify-center rounded-full border border-gold/30 text-gold transition hover:bg-gold/10 disabled:cursor-not-allowed disabled:opacity-40 disabled:hover:bg-transparent",
										children: "−"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "w-5 text-center text-sand-soft",
										"aria-live": "polite",
										children: guests
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										onClick: () => setGuests(Math.min(6, guests + 1)),
										disabled: atMax,
										"aria-label": "Increase guests",
										className: "flex h-8 w-8 items-center justify-center rounded-full border border-gold/30 text-gold transition hover:bg-gold/10 disabled:cursor-not-allowed disabled:opacity-40 disabled:hover:bg-transparent",
										children: "+"
									})
								]
							})]
						}), atMax && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-[11px] text-muted-foreground",
							children: "Maximum 6 guests per booking."
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					onClick: handleSearch,
					className: "group ml-1 flex shrink-0 items-center justify-center gap-2 whitespace-nowrap rounded-2xl bg-gold px-6 py-3.5 text-sm font-medium text-ink shadow-lg shadow-gold/20 transition hover:bg-gold-soft md:rounded-full md:px-7",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "h-4 w-4 transition group-hover:scale-110" }), "Check availability"]
				})
			]
		})
	});
}
function Hero({ onSearch }) {
	const { checkIn, checkOut } = useBooking();
	const nights = checkIn && checkOut ? Math.max(0, differenceInCalendarDays(checkOut, checkIn)) : 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		id: "hero",
		className: "relative min-h-[100svh] w-full overflow-hidden",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "absolute inset-0",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: hero_pyramids_default,
						alt: "Pyramids at golden hour",
						className: "h-full w-full object-cover",
						width: 1920,
						height: 1280
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-gradient-to-b from-ink/40 via-ink/30 to-ink" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-[radial-gradient(ellipse_at_center,transparent_0%,rgba(20,12,4,0.55)_75%)]" })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative z-10 mx-auto flex min-h-[100svh] max-w-7xl flex-col justify-center px-6 pb-[34rem] pt-28 sm:pb-[26rem] md:pb-80 md:pt-32",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.p, {
						initial: {
							opacity: 0,
							y: 14
						},
						animate: {
							opacity: 1,
							y: 0
						},
						transition: {
							duration: .9,
							delay: .2
						},
						className: "text-xs uppercase tracking-[0.4em] text-gold-soft/80",
						children: "Giza · Egypt"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.h1, {
						initial: {
							opacity: 0,
							y: 30
						},
						animate: {
							opacity: 1,
							y: 0
						},
						transition: {
							duration: 1.2,
							delay: .35,
							ease: [
								.2,
								.8,
								.2,
								1
							]
						},
						className: "text-gold-glow mt-5 font-display text-[18vw] leading-[0.88] tracking-tight text-sand-soft md:text-[10rem]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							"aria-hidden": "true",
							children: "Lavista"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "sr-only",
							children: "Lavista — Warm modern stay near the Pyramids of Giza"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.p, {
						initial: {
							opacity: 0,
							y: 16
						},
						animate: {
							opacity: 1,
							y: 0
						},
						transition: {
							duration: .9,
							delay: .7
						},
						className: "mt-6 max-w-xl text-base text-sand-soft/85 md:text-lg",
						children: "A warm, modern stay a short walk from the pyramids — built for travelers who want comfort, character, and a place to actually meet people."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "absolute inset-x-0 bottom-8 z-20 flex flex-col items-stretch gap-8 px-4 sm:gap-5 md:bottom-14 md:gap-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						"aria-live": "polite",
						className: "mx-auto text-center text-[11px] uppercase tracking-[0.32em] text-gold-soft/90",
						children: nights > 0 ? `${nights} night${nights > 1 ? "s" : ""} selected` : "Pick your dates to begin"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookingBar, { onSearch }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
						className: "mx-auto flex max-w-3xl flex-wrap items-center justify-center gap-x-6 gap-y-3 pt-2 text-[11px] text-sand-soft/60 md:pt-1",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex items-center gap-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Car, {
									className: "h-3.5 w-3.5 text-gold/70",
									"aria-hidden": "true"
								}), "Free parking"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex items-center gap-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plane, {
									className: "h-3.5 w-3.5 text-gold/70",
									"aria-hidden": "true"
								}), "Airport pickup available"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex items-center gap-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wallet, {
									className: "h-3.5 w-3.5 text-gold/70",
									"aria-hidden": "true"
								}), "No prepayment needed"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex items-center gap-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Coffee, {
									className: "h-3.5 w-3.5 text-gold/70",
									"aria-hidden": "true"
								}), "Breakfast"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex items-center gap-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CalendarCheck, {
									className: "h-3.5 w-3.5 text-gold/70",
									"aria-hidden": "true"
								}), "Free cancellation up to 24h before check-in"]
							})
						]
					})
				]
			})
		]
	});
}
function Navbar() {
	const [scrolled, setScrolled] = (0, import_react.useState)(false);
	const location = useLocation();
	const navigate = useNavigate();
	(0, import_react.useEffect)(() => {
		const onScroll = () => setScrolled(window.scrollY > 24);
		onScroll();
		window.addEventListener("scroll", onScroll, { passive: true });
		return () => window.removeEventListener("scroll", onScroll);
	}, []);
	const scrollToHero = () => {
		const el = document.getElementById("hero");
		if (el) el.scrollIntoView({
			behavior: "smooth",
			block: "start"
		});
		else window.scrollTo({
			top: 0,
			behavior: "smooth"
		});
	};
	const handleLogo = (e) => {
		e.preventDefault();
		if (location.pathname === "/") scrollToHero();
		else navigate({ to: "/" }).then(() => {
			setTimeout(scrollToHero, 80);
		});
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
		className: cn("fixed inset-x-0 top-0 z-50 transition-all duration-300", scrolled ? "border-b border-gold/10 bg-ink/75 backdrop-blur-md shadow-[0_4px_24px_-12px_rgba(0,0,0,0.6)]" : "border-b border-transparent bg-transparent"),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative mx-auto flex max-w-7xl items-center justify-between px-6 py-4 md:py-4 lg:py-5",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
					href: "/",
					onClick: handleLogo,
					className: "relative z-10 font-display text-xl tracking-tight text-sand-soft",
					"aria-label": "Lavista — back to top",
					children: ["Lavista", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-gold",
						children: "."
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "pointer-events-none absolute inset-x-0 top-1/2 hidden -translate-y-1/2 items-center justify-center md:flex",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "pointer-events-auto flex items-center gap-6 text-xs text-sand-soft/80 lg:gap-8 lg:text-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: "/#stay",
								className: "transition hover:text-gold",
								children: "Stay"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: "/#experiences",
								className: "transition hover:text-gold",
								children: "Experiences"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: "/#about",
								className: "transition hover:text-gold",
								children: "About"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: "/#location",
								className: "transition hover:text-gold",
								children: "Location"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: "/#faq",
								className: "transition hover:text-gold",
								children: "FAQ"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: "/#contact",
								className: "transition hover:text-gold",
								children: "Contact"
							})
						]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/manage-booking",
					className: "relative z-10 inline-flex items-center rounded-full border border-gold/40 px-2.5 py-1 text-[9px] font-medium uppercase tracking-[0.2em] text-gold transition hover:bg-gold/10 sm:px-3 sm:py-1.5 sm:text-[10px] md:px-2 md:py-1 md:text-[9px] lg:px-4 lg:py-2 lg:text-[11px] lg:tracking-[0.22em]",
					children: "Manage booking"
				})
			]
		})
	});
}
var CARD_FEATURE_LIMIT = 3;
function Rooms({ trigger }) {
	const { guests, checkIn, checkOut } = useBooking();
	const { data: all = [], isLoading } = useRooms();
	const { data: unavailable } = useUnavailableRooms(checkIn, checkOut);
	const [api, setApi] = (0, import_react.useState)(null);
	const [canPrev, setCanPrev] = (0, import_react.useState)(false);
	const [canNext, setCanNext] = (0, import_react.useState)(false);
	const rooms = trigger > 0 ? all.filter((r) => r.capacity >= guests && (!unavailable || !unavailable.has(r.id))) : all;
	(0, import_react.useEffect)(() => {
		if (!api) return;
		const update = () => {
			setCanPrev(api.canScrollPrev());
			setCanNext(api.canScrollNext());
		};
		update();
		api.on("select", update);
		api.on("reInit", update);
		return () => {
			api.off("select", update);
			api.off("reInit", update);
		};
	}, [api, rooms]);
	const showArrows = canPrev || canNext;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		id: "stay",
		className: "relative mx-auto max-w-7xl scroll-mt-24 px-6 py-28",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-8 flex items-end justify-between gap-4 md:mb-14 md:gap-6",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs uppercase tracking-[0.3em] text-gold",
				children: "Stay"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mt-3 font-display text-4xl text-sand-soft md:text-5xl",
				children: "Rooms made for resting"
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "hidden max-w-sm text-sm text-muted-foreground md:block",
					children: "Every room is designed around warm light and quiet comfort. No fuss, just a great place to sleep and start again."
				}), showArrows && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2 md:hidden",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => api?.scrollPrev(),
						disabled: !canPrev,
						"aria-label": "Previous rooms",
						className: "inline-flex h-10 w-10 items-center justify-center rounded-full border border-gold/30 text-sand-soft transition hover:border-gold hover:text-gold disabled:cursor-not-allowed disabled:opacity-30",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "h-4 w-4" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => api?.scrollNext(),
						disabled: !canNext,
						"aria-label": "Next rooms",
						className: "inline-flex h-10 w-10 items-center justify-center rounded-full border border-gold/30 text-sand-soft transition hover:border-gold hover:text-gold disabled:cursor-not-allowed disabled:opacity-30",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "h-4 w-4" })
					})]
				})]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AnimatePresence, {
			mode: "wait",
			children: isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.div, {
				initial: { opacity: 0 },
				animate: { opacity: 1 },
				exit: { opacity: 0 },
				className: "grid gap-6 md:grid-cols-3",
				children: [
					0,
					1,
					2
				].map((i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-[420px] animate-pulse rounded-3xl bg-card/60" }, i))
			}, "loading") : rooms.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "py-20 text-center text-muted-foreground",
				children: "No rooms match — try fewer guests or contact us."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
				initial: { opacity: 0 },
				animate: { opacity: 1 },
				className: "relative",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Carousel, {
					setApi,
					opts: {
						align: "start",
						containScroll: "trimSnaps"
					},
					className: "w-full",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CarouselContent, {
						className: "-ml-6",
						children: rooms.map((room, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CarouselItem, {
							className: "pl-6 sm:basis-1/2 lg:basis-1/3",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.article, {
								initial: {
									opacity: 0,
									y: 24
								},
								whileInView: {
									opacity: 1,
									y: 0
								},
								viewport: {
									once: true,
									margin: "-80px"
								},
								transition: {
									duration: .6,
									delay: i * .05
								},
								className: "group flex h-full flex-col overflow-hidden rounded-3xl border border-gold/10 bg-card transition hover:border-gold/30 hover:shadow-2xl hover:shadow-black/40",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "relative aspect-[4/3] overflow-hidden",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
										src: room.img,
										alt: room.type,
										className: "h-full w-full object-cover transition duration-700 group-hover:scale-105",
										loading: "lazy"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "absolute right-4 top-4 rounded-full bg-ink/70 px-3 py-1 text-xs text-gold backdrop-blur",
										children: [
											"$",
											room.price,
											"/night"
										]
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex flex-1 flex-col p-6",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center justify-between gap-3",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
												className: "font-display text-2xl text-sand-soft",
												children: room.type
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "flex shrink-0 items-center gap-1 text-xs text-muted-foreground",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, { className: "h-3.5 w-3.5" }),
													" ",
													room.capacity
												]
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-2 text-sm text-muted-foreground",
											children: room.desc
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "mt-4 flex flex-wrap gap-2",
											children: [room.features.slice(0, CARD_FEATURE_LIMIT).map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "rounded-full border border-gold/20 px-2.5 py-1 text-[11px] text-sand-soft/80",
												children: f
											}, f)), room.features.length > CARD_FEATURE_LIMIT && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "rounded-full border border-gold/20 px-2.5 py-1 text-[11px] text-sand-soft/60",
												children: "…"
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "mt-auto flex items-center justify-between gap-3 pt-6",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
												to: "/rooms/$id",
												params: { id: room.id },
												className: "text-sm text-sand-soft/80 transition hover:text-gold",
												children: "View details"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
												to: "/booking/guest",
												onClick: () => preselectRoom(room.id),
												className: "inline-flex items-center gap-1.5 rounded-full bg-gold px-4 py-2 text-xs font-medium text-ink transition hover:bg-gold-soft",
												children: ["Book ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "h-3.5 w-3.5" })]
											})]
										})
									]
								})]
							})
						}, room.id))
					})
				}), showArrows && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => api?.scrollPrev(),
					disabled: !canPrev,
					"aria-label": "Previous rooms",
					className: "absolute left-0 top-1/2 z-10 -translate-y-1/2 -translate-x-2 hidden md:inline-flex h-11 w-11 items-center justify-center rounded-full border border-gold/30 bg-ink/80 text-sand-soft backdrop-blur transition hover:border-gold hover:text-gold disabled:cursor-not-allowed disabled:opacity-30 lg:-translate-x-5",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "h-4 w-4" })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => api?.scrollNext(),
					disabled: !canNext,
					"aria-label": "Next rooms",
					className: "absolute right-0 top-1/2 z-10 -translate-y-1/2 translate-x-2 hidden md:inline-flex h-11 w-11 items-center justify-center rounded-full border border-gold/30 bg-ink/80 text-sand-soft backdrop-blur transition hover:border-gold hover:text-gold disabled:cursor-not-allowed disabled:opacity-30 lg:translate-x-5",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "h-4 w-4" })
				})] })]
			}, "rooms")
		})]
	});
}
function ExperienceCard({ e, index }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
		initial: {
			opacity: 0,
			y: 24
		},
		whileInView: {
			opacity: 1,
			y: 0
		},
		viewport: {
			once: true,
			margin: "-80px"
		},
		transition: {
			duration: .6,
			delay: index * .06,
			ease: [
				.2,
				.8,
				.2,
				1
			]
		},
		className: "group relative isolate flex aspect-square h-full w-full overflow-hidden rounded-3xl border border-white/5 bg-card shadow-[0_30px_60px_-30px_rgba(0,0,0,0.7)] transition-[border-color,box-shadow] duration-500 hover:border-gold/30 hover:shadow-[0_40px_80px_-30px_color-mix(in_oklab,var(--gold)_25%,transparent)]",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/experiences/$slug",
				params: { slug: e.slug },
				"aria-label": `View ${e.title} details`,
				className: "absolute inset-0 z-20"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "absolute inset-0 overflow-hidden",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: e.img,
					alt: e.title,
					loading: "lazy",
					className: "h-full w-full object-cover transition-transform duration-[1400ms] ease-out group-hover:scale-[1.08]"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none absolute inset-0 bg-gradient-to-t from-ink via-ink/55 to-transparent" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none absolute inset-0 bg-gradient-to-t from-ink/80 via-ink/20 to-transparent opacity-0 transition-opacity duration-500 group-hover:opacity-100" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "absolute left-5 top-5 z-10 inline-flex items-center gap-1.5 rounded-full border border-white/15 bg-ink/50 px-3 py-1 backdrop-blur-md",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-1.5 w-1.5 rounded-full bg-gold shadow-[0_0_8px_var(--gold)]" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-[10px] uppercase tracking-[0.22em] text-sand-soft/90",
					children: e.tag
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative z-10 mt-auto w-full p-5 md:p-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "font-display text-2xl leading-tight text-sand-soft md:text-3xl",
						children: e.title
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 line-clamp-2 max-w-md text-sm leading-relaxed text-sand-soft/75",
						children: e.blurb
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-5 flex items-center justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "inline-flex items-center gap-2 rounded-full bg-gold px-4 py-2.5 text-[11px] font-medium uppercase tracking-[0.2em] text-ink shadow-[0_8px_24px_-8px_color-mix(in_oklab,var(--gold)_70%,transparent)] transition duration-300 group-hover:gap-3",
							children: "View details"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "flex h-9 w-9 items-center justify-center rounded-full border border-white/15 bg-ink/40 text-sand-soft backdrop-blur-md transition group-hover:border-gold/50 group-hover:text-gold",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, { className: "h-4 w-4 transition group-hover:-translate-y-0.5 group-hover:translate-x-0.5" })
						})]
					})
				]
			})
		]
	});
}
function Experiences() {
	const { data: db } = useExperiencesContent();
	const EXP = db && db.length > 0 ? db.map((e) => ({
		slug: e.slug,
		img: e.img || EXPERIENCES[0]?.img || "",
		title: e.title,
		tag: e.tag,
		blurb: e.blurb
	})) : EXPERIENCES;
	const count = EXP.length;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		id: "experiences",
		className: "relative overflow-hidden bg-gradient-to-b from-background via-card/40 to-background py-24 md:py-32",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-gold/30 to-transparent" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none absolute -top-40 left-1/2 h-80 w-[60rem] -translate-x-1/2 rounded-full bg-gold/5 blur-3xl" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto max-w-7xl px-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-16 flex flex-col items-start justify-between gap-6 md:mb-20 md:flex-row md:items-end",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "max-w-2xl",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[11px] uppercase tracking-[0.32em] text-gold",
									children: "Experiences & Trips"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
									className: "mt-4 font-display text-4xl leading-[1.05] text-sand-soft md:text-5xl lg:text-6xl",
									children: ["Things to do, ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "italic text-gold-soft",
										children: "the local way"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-5 max-w-lg text-base leading-relaxed text-muted-foreground",
									children: "Hand-picked trips with friends of the house. Tell us what you're into and we'll tailor every detail."
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
							href: WHATSAPP,
							target: "_blank",
							rel: "noreferrer",
							className: "group hidden items-center gap-2 rounded-full border border-gold/30 px-5 py-2.5 text-xs uppercase tracking-[0.22em] text-sand-soft transition hover:border-gold hover:bg-gold/10 hover:text-gold md:inline-flex",
							children: ["Plan my trip ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, { className: "h-3.5 w-3.5 transition group-hover:-translate-y-0.5 group-hover:translate-x-0.5" })]
						})]
					}),
					count === 0 ? null : count === 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex justify-center",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "w-full max-w-md",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExperienceCard, {
								e: EXP[0],
								index: 0
							})
						})
					}) : count <= 3 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: `mx-auto grid gap-6 ${count === 2 ? "max-w-4xl grid-cols-1 sm:grid-cols-2" : "max-w-6xl grid-cols-1 sm:grid-cols-2 lg:grid-cols-3"}`,
						children: EXP.map((e, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExperienceCard, {
							e,
							index: i
						}, e.slug))
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Carousel, {
						opts: {
							align: "start",
							loop: false
						},
						className: "w-full",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CarouselContent, {
							className: "-ml-4",
							children: EXP.map((e, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CarouselItem, {
								className: "basis-full pl-4 sm:basis-1/2 lg:basis-1/3",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExperienceCard, {
									e,
									index: i
								})
							}, e.slug))
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-8 hidden justify-end gap-2 md:flex",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CarouselPrevious, { className: "static translate-x-0 translate-y-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CarouselNext, { className: "static translate-x-0 translate-y-0" })]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-10 flex justify-center md:hidden",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
							href: WHATSAPP,
							target: "_blank",
							rel: "noreferrer",
							className: "inline-flex w-full items-center justify-center gap-2 rounded-full bg-gold px-6 py-4 text-xs font-medium uppercase tracking-[0.22em] text-ink shadow-[0_12px_30px_-10px_color-mix(in_oklab,var(--gold)_70%,transparent)]",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageCircle, { className: "h-4 w-4" }), " Plan my trip on WhatsApp"]
						})
					})
				]
			})
		]
	});
}
var WA_PICKUP = "https://wa.me/201007695392?text=" + encodeURIComponent("Hi Lavista — I'd like to arrange an airport pickup. Here are my flight details:");
function AirportPickup() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		id: "airport-pickup",
		className: "mx-auto max-w-7xl px-6 py-20",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative overflow-hidden rounded-3xl border border-gold/15 bg-gradient-to-br from-card via-card/80 to-ink p-8 md:p-12",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none absolute -right-24 -top-24 h-72 w-72 rounded-full bg-gold/10 blur-3xl" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative grid items-center gap-8 md:grid-cols-[1fr_auto]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-start gap-5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "grid h-14 w-14 shrink-0 place-items-center rounded-2xl border border-gold/30 bg-ink/40 text-gold",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plane, {
							className: "h-6 w-6",
							"aria-hidden": "true"
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[11px] uppercase tracking-[0.32em] text-gold",
								children: "Service"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "mt-2 font-display text-3xl text-sand-soft md:text-4xl",
								children: "Airport pickup, on us to arrange"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 max-w-xl text-sm leading-relaxed text-muted-foreground md:text-base",
								children: "Land tired, skip the queue. Share your flight details and we'll meet you at Cairo Airport with a fixed, fair price — no haggling."
							})
						]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
					href: WA_PICKUP,
					target: "_blank",
					rel: "noreferrer",
					className: "inline-flex items-center justify-center gap-2 self-center rounded-full bg-gold px-7 py-4 text-xs font-medium uppercase tracking-[0.22em] text-ink shadow-[0_12px_30px_-10px_color-mix(in_oklab,var(--gold)_70%,transparent)] transition hover:bg-gold-soft",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageCircle, { className: "h-4 w-4" }), " Contact"]
				})]
			})]
		})
	});
}
var gallery_lounge_default = "/assets/gallery-lounge-Cukc-D6a.jpg";
function About() {
	const { data: content } = useWebsiteContent();
	const { data: images } = useAboutImages();
	const eyebrow = content?.about_eyebrow ?? "About Lavista";
	const title = content?.about_title ?? "A warm corner of Giza, ten minutes from the pyramids.";
	const highlight = content?.about_highlight ?? "";
	const p1 = content?.about_paragraph_1 ?? "Lavista was built for people who care about the feeling of a place. Soft beds, kind staff, a rooftop that catches the sunset, and a common room where travelers from everywhere end up trading stories over mint tea.";
	const p2 = content?.about_paragraph_2 ?? "Affordable. Comfortable. Quietly beautiful. Modern Egyptian hospitality without the gold-plated pretense.";
	const heroImg = images && images.length > 0 ? images[0] : gallery_lounge_default;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		id: "about",
		className: "mx-auto grid max-w-7xl gap-12 px-6 py-28 md:grid-cols-2 md:items-center",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
			initial: {
				opacity: 0,
				x: -30
			},
			whileInView: {
				opacity: 1,
				x: 0
			},
			viewport: { once: true },
			transition: { duration: .8 },
			className: "relative overflow-hidden rounded-3xl",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: heroImg,
				alt: "Lavista lounge",
				loading: "lazy",
				className: "h-full w-full object-cover"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-gradient-to-tr from-ink/40 to-transparent" })]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs uppercase tracking-[0.3em] text-gold",
				children: eyebrow
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mt-3 font-display text-4xl text-sand-soft md:text-5xl",
				children: title
			}),
			highlight && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 font-display text-lg italic text-gold-soft",
				children: highlight
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-6 text-muted-foreground",
				children: p1
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 text-muted-foreground",
				children: p2
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-8 grid grid-cols-3 gap-6",
				children: [
					{
						k: "4.9",
						v: "Guest rating"
					},
					{
						k: "10 min",
						v: "To Giza"
					},
					{
						k: "24/7",
						v: "Front desk"
					}
				].map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-3xl text-gold",
					children: s.k
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-xs uppercase tracking-wider text-muted-foreground",
					children: s.v
				})] }, s.v))
			})
		] })]
	});
}
var FALLBACK_REVIEWS = [
	{
		name: "Lena",
		from: "Berlin",
		text: "Honestly the warmest hostel I've stayed at. The rooftop at sunset is unreal — pyramids glowing in the distance.",
		rating: 5,
		avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=160&h=160&fit=crop&crop=faces"
	},
	{
		name: "Marco & Sofia",
		from: "Milan",
		text: "We came for two nights, stayed five. The staff felt like friends by day two.",
		rating: 5,
		avatar: "https://images.unsplash.com/photo-1521119989659-a83eee488004?w=160&h=160&fit=crop&crop=faces"
	},
	{
		name: "Yusuke",
		from: "Tokyo",
		text: "Clean, quiet, beautifully designed. Great Wi-Fi for remote work and a proper coffee in the morning.",
		rating: 5,
		avatar: "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=160&h=160&fit=crop&crop=faces"
	}
];
function Testimonials() {
	const { data: db } = useReviewsContent();
	const REVIEWS = db && db.length > 0 ? db.map((r) => ({
		name: r.name,
		from: r.from ?? "",
		text: r.text,
		rating: r.rating ?? 5,
		avatar: r.avatar || ""
	})) : FALLBACK_REVIEWS;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "bg-card/40 py-28",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-7xl px-6",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-14 text-center",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs uppercase tracking-[0.3em] text-gold",
					children: "Travelers"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-3 font-display text-4xl text-sand-soft md:text-5xl",
					children: "Loved by people passing through"
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-6 md:grid-cols-3",
				children: REVIEWS.map((r, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
					initial: {
						opacity: 0,
						y: 20
					},
					whileInView: {
						opacity: 1,
						y: 0
					},
					viewport: { once: true },
					transition: {
						duration: .5,
						delay: i * .1
					},
					className: "rounded-3xl border border-gold/10 bg-background/60 p-7 backdrop-blur",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col gap-3 sm:flex-row sm:items-center md:flex-col md:items-start md:gap-4 lg:flex-row lg:items-center",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: r.avatar,
								alt: `${r.name} avatar`,
								loading: "lazy",
								className: "h-12 w-12 shrink-0 rounded-full border border-gold/30 object-cover"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "truncate text-sm text-sand-soft",
									children: r.name
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "truncate text-xs text-muted-foreground",
									children: r.from
								})]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex shrink-0 gap-0.5 text-gold sm:ml-auto md:ml-0 lg:ml-auto",
							children: Array.from({ length: r.rating }).map((_, k) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Star, { className: "h-3.5 w-3.5 fill-current" }, k))
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-5 text-sand-soft/90",
						children: [
							"\"",
							r.text,
							"\""
						]
					})]
				}, r.name))
			})]
		})
	});
}
var Accordion = Root2;
var AccordionItem = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Item, {
	ref,
	className: cn("border-b", className),
	...props
}));
AccordionItem.displayName = "AccordionItem";
var AccordionTrigger = import_react.forwardRef(({ className, children, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Header, {
	className: "flex",
	children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Trigger2, {
		ref,
		className: cn("flex flex-1 items-center justify-between py-4 text-sm font-medium cursor-pointer transition-all hover:underline text-left [&[data-state=open]>svg]:rotate-180", className),
		...props,
		children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: "h-4 w-4 shrink-0 text-muted-foreground transition-transform duration-200" })]
	})
}));
AccordionTrigger.displayName = Trigger2.displayName;
var AccordionContent = import_react.forwardRef(({ className, children, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Content2, {
	ref,
	className: "overflow-hidden text-sm data-[state=closed]:animate-accordion-up data-[state=open]:animate-accordion-down",
	...props,
	children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("pb-4 pt-0", className),
		children
	})
}));
AccordionContent.displayName = Content2.displayName;
var FAQS = [
	{
		q: "How far is Lavista from the Pyramids of Giza?",
		a: "Lavista is a 7–10 minute walk from the entrance of the Giza Plateau, with a clear view of the pyramids from our rooftop."
	},
	{
		q: "Do you offer airport pickup from Cairo International Airport?",
		a: "Yes — we arrange private, fixed-price transfers (about 45–60 minutes). Message us on WhatsApp with your flight details and we'll handle the rest."
	},
	{
		q: "What is the check-in and check-out time?",
		a: "Check-in from 2:00 PM, check-out by 11:00 AM. Early check-in and late check-out are usually possible — just ask."
	},
	{
		q: "Is breakfast included?",
		a: "Breakfast is included with Cozy Double and Pyramid View Suite bookings, and available à la carte for Twin Shared guests on the rooftop."
	},
	{
		q: "Can you arrange tours and experiences?",
		a: "Yes — pyramid tours, Nile cruises, desert safaris, and food walks are all bookable through reception or our WhatsApp."
	},
	{
		q: "Do you accept walk-ins?",
		a: "When we have availability, yes. During high season (October–April) we strongly recommend booking ahead."
	},
	{
		q: "Is the area around Lavista safe for solo travelers and couples?",
		a: "Absolutely. Nazlet El-Semman is a friendly, well-lit neighborhood with locals you'll recognize within a day. We also offer 24/7 reception."
	}
];
function FAQ() {
	const { data: dbFaqs } = useFaqContent();
	const items = dbFaqs && dbFaqs.length > 0 ? dbFaqs : FAQS;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		id: "faq",
		className: "relative mx-auto max-w-4xl px-6 py-24 md:py-32",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-12 text-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs uppercase tracking-[0.3em] text-gold",
						children: "FAQ"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-3 font-display text-4xl text-sand-soft md:text-5xl",
						children: "Good questions, honest answers"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mx-auto mt-4 max-w-xl text-sm text-muted-foreground",
						children: "Everything travelers ask before they book — about the stay, the pyramids, and getting around Giza."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Accordion, {
				type: "single",
				collapsible: true,
				className: "w-full",
				children: items.map((f, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AccordionItem, {
					value: `item-${i}`,
					className: "border-gold/15",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AccordionTrigger, {
						className: "text-left font-display text-lg text-sand-soft hover:text-gold hover:no-underline",
						children: f.q
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AccordionContent, {
						className: "text-sm leading-relaxed text-sand-soft/80",
						children: f.a
					})]
				}, i))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("script", {
				type: "application/ld+json",
				dangerouslySetInnerHTML: { __html: JSON.stringify({
					"@context": "https://schema.org",
					"@type": "FAQPage",
					mainEntity: items.map((f) => ({
						"@type": "Question",
						name: f.q,
						acceptedAnswer: {
							"@type": "Answer",
							text: f.a
						}
					}))
				}) }
			})
		]
	});
}
var EMBED_URL = "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d1227.3390534210455!2d31.141987109667607!3d29.97978952349126!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x14584508df92d129%3A0x8720019934c121f!2sLa%20vista%20pyramids%20view!5e1!3m2!1sen!2seg!4v1782256490145!5m2!1sen!2seg";
function Location() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		id: "location",
		className: "relative mx-auto max-w-7xl scroll-mt-24 px-6 py-24 md:py-28",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-10 lg:grid-cols-2 lg:items-stretch lg:gap-14",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col justify-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs uppercase tracking-[0.3em] text-gold",
						children: "Location"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-3 font-display text-4xl text-sand-soft md:text-5xl",
						children: "A short walk from the pyramids"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-5 max-w-md text-sm leading-relaxed text-muted-foreground md:text-base",
						children: "Tucked into the quiet streets of Nazlet El-Semman, Lavista sits within walking distance of the Great Pyramid and the Sphinx. Step out for sunrise at the plateau, return for tea on the rooftop."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-7 space-y-3 text-sm text-sand-soft/85",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex items-start gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "mt-0.5 h-4 w-4 shrink-0 text-gold" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Nazlet El-Semman, Giza, Egypt" })]
						})
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "absolute -inset-3 rounded-[2rem] bg-gradient-to-br from-gold/15 via-transparent to-transparent blur-2xl",
					"aria-hidden": true
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "relative overflow-hidden rounded-[1.75rem] border border-gold/15 bg-card shadow-2xl shadow-black/40",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("iframe", {
						title: "Lavista — Pyramids view location",
						src: EMBED_URL,
						loading: "lazy",
						referrerPolicy: "no-referrer-when-downgrade",
						allowFullScreen: true,
						className: "block h-[360px] w-full md:h-[460px] lg:h-[520px]",
						style: {
							border: 0,
							filter: "grayscale(0.15) contrast(1.05)"
						}
					})
				})]
			})]
		})
	});
}
function Index() {
	const [searchTrigger, setSearchTrigger] = (0, import_react.useState)(0);
	const roomsRef = (0, import_react.useRef)(null);
	const onSearch = () => {
		setSearchTrigger((n) => n + 1);
		setTimeout(() => {
			roomsRef.current?.scrollIntoView({
				behavior: "smooth",
				block: "start"
			});
		}, 80);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookingProvider, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "min-h-screen bg-background text-foreground",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Navbar, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Hero, { onSearch }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				ref: roomsRef,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Rooms, { trigger: searchTrigger })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Experiences, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AirportPickup, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(About, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Testimonials, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Location, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FAQ, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Footer, {})
		]
	}) });
}
//#endregion
export { Index as component };
