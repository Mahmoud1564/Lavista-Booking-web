import { a as __toESM } from "../_runtime.mjs";
import { t as motion } from "../_libs/framer-motion.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { h as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { n as useRooms, t as useRoom } from "./use-rooms-BVO5iBq1.mjs";
import { f as Link, m as useSearch } from "../_libs/@tanstack/react-router+[...].mjs";
import { E as Check, N as ArrowRight, P as ArrowLeft, c as MessageCircle, k as CalendarDays, r as Users } from "../_libs/lucide-react.mjs";
import { t as Footer } from "./Footer-BnjllBH7.mjs";
import { a as CarouselPrevious, i as CarouselNext, n as CarouselContent, r as CarouselItem, t as Carousel } from "./carousel-mra82WDg.mjs";
import { t as Route } from "./rooms._id-Vi1F-P-l.mjs";
import { t as preselectRoom } from "./preselect-room-BCd5dsKT.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/rooms._id-mfZWoWrZ.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function AmenitiesList({ items }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
		className: "grid grid-cols-1 gap-2 sm:grid-cols-2",
		children: items.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
			className: "flex items-center gap-2 text-sm text-sand-soft/85",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "h-4 w-4 shrink-0 text-gold" }),
				" ",
				a
			]
		}, a))
	}) });
}
var WA = "https://wa.me/201007695392";
function RoomDetail() {
	const { id } = Route.useParams();
	const { data: room, isLoading, error } = useRoom(id);
	const { data: all = [] } = useRooms();
	const { from } = useSearch({ from: "/rooms/$id" });
	const fromBooking = from === "booking";
	const [api, setApi] = (0, import_react.useState)(null);
	const [current, setCurrent] = (0, import_react.useState)(0);
	(0, import_react.useEffect)(() => {
		if (!api) return;
		setCurrent(api.selectedScrollSnap());
		const onSel = () => setCurrent(api.selectedScrollSnap());
		api.on("select", onSel);
		api.on("reInit", onSel);
		return () => {
			api.off("select", onSel);
		};
	}, [api]);
	if (isLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "flex min-h-screen items-center justify-center bg-background text-sand-soft/70",
		children: "Loading room…"
	});
	if (error || !room) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "flex min-h-screen items-center justify-center bg-background px-4 text-center",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "font-display text-4xl text-sand-soft",
			children: "Room not found"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: "/",
			className: "mt-6 inline-block text-gold underline",
			children: "Back home"
		})] })
	});
	const related = all.filter((r) => r.id !== room.id);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "min-h-screen bg-background text-foreground",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
				className: "mx-auto flex max-w-7xl items-center justify-between px-6 pt-7 md:pt-10",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/",
					className: "font-display text-xl tracking-tight text-sand-soft",
					children: ["Lavista", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-gold",
						children: "."
					})]
				}), fromBooking ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/booking/rooms",
					className: "inline-flex items-center gap-2 text-sm text-sand-soft/80 transition hover:text-gold",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "h-4 w-4" }), " Back to booking"]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/",
					className: "inline-flex items-center gap-2 text-sm text-sand-soft/80 transition hover:text-gold",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "h-4 w-4" }), " Back"]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mx-auto grid max-w-7xl gap-10 px-6 py-12 lg:grid-cols-[1.3fr_1fr]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.div, {
					initial: {
						opacity: 0,
						y: 20
					},
					animate: {
						opacity: 1,
						y: 0
					},
					transition: { duration: .6 },
					children: (() => {
						const imgs = room.gallery.length > 0 ? room.gallery : [room.img];
						const total = imgs.length;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Carousel, {
								setApi,
								opts: {
									align: "start",
									loop: total > 1
								},
								className: "w-full",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CarouselContent, { children: imgs.map((src, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CarouselItem, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "relative aspect-[4/3] overflow-hidden rounded-3xl border border-gold/10",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
										src,
										alt: `${room.type} — ${i + 1}`,
										className: "h-full w-full object-cover"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "pointer-events-none absolute right-3 top-3 rounded-full bg-ink/70 px-3 py-1 text-[11px] font-medium tracking-[0.15em] text-sand-soft backdrop-blur",
										children: [
											i + 1,
											" / ",
											total
										]
									})]
								}) }, i)) }), total > 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CarouselPrevious, { className: "left-3" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CarouselNext, { className: "right-3" })] })]
							}),
							total > 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-4 flex items-center justify-between gap-3",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-[11px] uppercase tracking-[0.22em] text-muted-foreground",
									children: [
										"Image ",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-sand-soft",
											children: current + 1
										}),
										" of",
										" ",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-sand-soft",
											children: total
										})
									]
								})
							}),
							total > 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-3 grid grid-cols-5 gap-2 sm:grid-cols-6 md:grid-cols-8",
								children: imgs.map((src, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => api?.scrollTo(i),
									"aria-label": `Show image ${i + 1}`,
									"aria-current": current === i,
									className: `relative aspect-square overflow-hidden rounded-lg border transition ${current === i ? "border-gold shadow-[0_0_0_2px_color-mix(in_oklab,var(--gold)_35%,transparent)]" : "border-white/10 opacity-70 hover:opacity-100"}`,
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
										src,
										alt: "",
										className: "h-full w-full object-cover"
									})
								}, `thumb-${i}`))
							})
						] });
					})()
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
					initial: {
						opacity: 0,
						y: 20
					},
					animate: {
						opacity: 1,
						y: 0
					},
					transition: {
						duration: .6,
						delay: .1
					},
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs uppercase tracking-[0.3em] text-gold",
							children: "Stay · Giza, Egypt"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "mt-3 font-display text-4xl text-sand-soft md:text-5xl",
							children: room.type
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4 flex items-baseline gap-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "font-display text-3xl text-gold",
									children: ["$", room.price]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-sm text-muted-foreground",
									children: "/ night"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "ml-auto inline-flex items-center gap-1.5 text-sm text-muted-foreground",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, { className: "h-4 w-4" }),
										" Sleeps ",
										room.capacity
									]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-6 text-base leading-relaxed text-sand-soft/85",
							children: room.long
						}),
						room.amenities.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-8",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs uppercase tracking-[0.22em] text-gold",
								children: "Amenities"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-4",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AmenitiesList, { items: room.amenities })
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-8 rounded-2xl border border-gold/15 bg-card/60 p-5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "flex items-center gap-2 text-xs uppercase tracking-[0.22em] text-gold",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CalendarDays, { className: "h-3.5 w-3.5" }), " Availability"]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm text-sand-soft/85",
								children: room.availability
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-8 flex flex-wrap gap-3",
							children: [fromBooking ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/booking/rooms",
								onClick: () => preselectRoom(room.id),
								className: "inline-flex flex-1 items-center justify-center gap-2 rounded-full bg-gold px-6 py-4 text-sm font-medium uppercase tracking-[0.2em] text-ink transition hover:bg-gold-soft",
								children: "Select this room"
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/booking/guest",
								onClick: () => preselectRoom(room.id),
								className: "inline-flex flex-1 items-center justify-center gap-2 rounded-full bg-gold px-6 py-4 text-sm font-medium uppercase tracking-[0.2em] text-ink transition hover:bg-gold-soft",
								children: "Book Now"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
								href: WA,
								target: "_blank",
								rel: "noreferrer",
								className: "inline-flex items-center justify-center gap-2 rounded-full border border-gold/30 px-6 py-4 text-sm font-medium uppercase tracking-[0.2em] text-sand-soft transition hover:bg-gold/10",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageCircle, { className: "h-4 w-4" }), " Contact"]
							})]
						})
					]
				})]
			}),
			related.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mx-auto max-w-7xl px-6 py-20",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-10",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs uppercase tracking-[0.3em] text-gold",
						children: "Other rooms"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-3 font-display text-3xl text-sand-soft md:text-4xl",
						children: "Other rooms to rest in"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid gap-6 md:grid-cols-2",
					children: related.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/rooms/$id",
						params: { id: r.id },
						className: "group overflow-hidden rounded-3xl border border-gold/10 bg-card transition hover:border-gold/30",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "aspect-[16/9] overflow-hidden",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: r.img,
								alt: r.type,
								className: "h-full w-full object-cover transition duration-700 group-hover:scale-105"
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between p-5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "font-display text-xl text-sand-soft",
								children: r.type
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-xs text-muted-foreground",
								children: [
									"$",
									r.price,
									"/night"
								]
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "h-4 w-4 text-gold transition group-hover:translate-x-1" })]
						})]
					}, r.id))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Footer, {})
		]
	});
}
//#endregion
export { RoomDetail as component };
