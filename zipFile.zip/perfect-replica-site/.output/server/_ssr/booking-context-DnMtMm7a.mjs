import { a as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { h as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/booking-context-DnMtMm7a.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var BookingCtx = (0, import_react.createContext)(null);
var KEY = "lavista.search";
function load() {
	if (typeof window === "undefined") return {};
	try {
		return JSON.parse(window.localStorage.getItem(KEY) ?? "{}");
	} catch {
		return {};
	}
}
function BookingProvider({ children }) {
	const [checkIn, setCheckIn] = (0, import_react.useState)();
	const [checkOut, setCheckOut] = (0, import_react.useState)();
	const [guests, setGuestsRaw] = (0, import_react.useState)(2);
	const [hydrated, setHydrated] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		const s = load();
		if (s.guests) setGuestsRaw(Math.min(6, Math.max(1, s.guests)));
		setHydrated(true);
	}, []);
	(0, import_react.useEffect)(() => {
		if (!hydrated || typeof window === "undefined") return;
		window.localStorage.setItem(KEY, JSON.stringify({ guests }));
	}, [guests, hydrated]);
	const setGuests = (n) => setGuestsRaw(Math.min(6, Math.max(1, n)));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookingCtx.Provider, {
		value: {
			checkIn,
			checkOut,
			guests,
			setCheckIn,
			setCheckOut,
			setGuests
		},
		children
	});
}
function useBooking() {
	const ctx = (0, import_react.useContext)(BookingCtx);
	if (!ctx) throw new Error("useBooking must be inside BookingProvider");
	return ctx;
}
//#endregion
export { useBooking as n, BookingProvider as t };
