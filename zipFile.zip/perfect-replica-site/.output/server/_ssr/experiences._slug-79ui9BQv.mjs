import { t as motion } from "../_libs/framer-motion.mjs";
import { h as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { f as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { N as ArrowRight, P as ArrowLeft, b as Clock, c as MessageCircle, k as CalendarDays, l as MapPin } from "../_libs/lucide-react.mjs";
import { t as Footer } from "./Footer-BnjllBH7.mjs";
import { r as getExperience, t as EXPERIENCES } from "./experiences-T1CP3tmx.mjs";
import { t as Route } from "./experiences._slug-DBL3x9Wt.mjs";
import { n as useExperiencesContent } from "./use-content-D3tyqQHR.mjs";
import { a as CarouselPrevious, i as CarouselNext, n as CarouselContent, r as CarouselItem, t as Carousel } from "./carousel-mra82WDg.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/experiences._slug-79ui9BQv.js
var import_jsx_runtime = require_jsx_runtime();
function ExperienceDetail() {
	const { slug } = Route.useParams();
	const { data: dbList } = useExperiencesContent();
	const dbExp = dbList?.find((e) => e.slug === slug);
	const fallbackExp = getExperience(slug);
	if (!dbExp && !fallbackExp) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center bg-background px-4 text-center",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "font-display text-4xl text-sand-soft",
			children: "Experience not found"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: "/",
			className: "mt-6 inline-block text-gold underline",
			children: "Back home"
		})] })
	});
	const exp = dbExp ? {
		slug: dbExp.slug,
		title: dbExp.title,
		blurb: dbExp.blurb,
		long: dbExp.long || dbExp.blurb,
		tag: dbExp.tag,
		duration: dbExp.duration || (fallbackExp?.duration ?? ""),
		meeting: dbExp.meeting || (fallbackExp?.meeting ?? ""),
		dates: dbExp.dates || (fallbackExp?.dates ?? ""),
		price: fallbackExp?.price ?? "",
		img: dbExp.img || fallbackExp?.img || "",
		gallery: dbExp.gallery.length > 0 ? dbExp.gallery : fallbackExp?.gallery ?? []
	} : fallbackExp;
	const related = dbList && dbList.length > 0 ? dbList.filter((e) => e.slug !== exp.slug).slice(0, 3).map((e) => ({
		slug: e.slug,
		title: e.title,
		img: e.img,
		duration: e.duration
	})) : EXPERIENCES.filter((e) => e.slug !== exp.slug).slice(0, 3);
	const waMsg = `https://wa.me/201007695392?text=${encodeURIComponent(`Hi Lavista — I'd like to book the ${exp.title} experience.`)}`;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "min-h-screen bg-background text-foreground",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
				className: "mx-auto flex max-w-7xl items-center justify-between px-6 pt-7 md:pt-10",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/",
					className: "font-display text-xl tracking-tight text-sand-soft",
					children: ["Lavista", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-gold",
						children: "."
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/",
					className: "inline-flex items-center gap-2 text-sm text-sand-soft/80 transition hover:text-gold",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "h-4 w-4" }), " Back"]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mx-auto grid max-w-7xl gap-10 px-6 py-12 lg:grid-cols-[1.3fr_1fr]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.div, {
					initial: {
						opacity: 0,
						y: 20
					},
					animate: {
						opacity: 1,
						y: 0
					},
					transition: { duration: .6 },
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Carousel, {
						opts: {
							align: "start",
							loop: exp.gallery.length > 1
						},
						className: "w-full",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CarouselContent, { children: (exp.gallery.length > 0 ? exp.gallery : [exp.img]).map((src, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CarouselItem, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative aspect-[4/3] overflow-hidden rounded-3xl border border-gold/10",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src,
								alt: `${exp.title} — ${i + 1}`,
								className: "h-full w-full object-cover"
							}), i === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "absolute left-5 top-5 inline-flex items-center gap-1.5 rounded-full border border-white/15 bg-ink/50 px-3 py-1 backdrop-blur-md",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-1.5 w-1.5 rounded-full bg-gold" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[10px] uppercase tracking-[0.22em] text-sand-soft/90",
									children: exp.tag
								})]
							})]
						}) }, i)) }), exp.gallery.length > 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CarouselPrevious, { className: "left-3" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CarouselNext, { className: "right-3" })] })]
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
					initial: {
						opacity: 0,
						y: 20
					},
					animate: {
						opacity: 1,
						y: 0
					},
					transition: {
						duration: .6,
						delay: .1
					},
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs uppercase tracking-[0.3em] text-gold",
							children: "Experience · Giza, Egypt"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "mt-3 font-display text-4xl text-sand-soft md:text-5xl",
							children: exp.title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-6 text-base leading-relaxed text-sand-soft/85",
							children: exp.long
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-8 grid gap-4 sm:grid-cols-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "rounded-2xl border border-gold/15 bg-card/60 p-5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "flex items-center gap-2 text-xs uppercase tracking-[0.22em] text-gold",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "h-3.5 w-3.5" }), " Duration"]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-2 text-sm text-sand-soft/85",
										children: exp.duration
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "rounded-2xl border border-gold/15 bg-card/60 p-5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "flex items-center gap-2 text-xs uppercase tracking-[0.22em] text-gold",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CalendarDays, { className: "h-3.5 w-3.5" }), " Available dates"]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-2 text-sm text-sand-soft/85",
										children: exp.dates
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "rounded-2xl border border-gold/15 bg-card/60 p-5 sm:col-span-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "flex items-center gap-2 text-xs uppercase tracking-[0.22em] text-gold",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "h-3.5 w-3.5" }), " Meeting / pickup"]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-2 text-sm text-sand-soft/85",
										children: exp.meeting
									})]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
							href: waMsg,
							target: "_blank",
							rel: "noreferrer",
							className: "mt-8 inline-flex w-full items-center justify-center gap-2 rounded-full bg-gold px-6 py-4 text-sm font-medium uppercase tracking-[0.2em] text-ink transition hover:bg-gold-soft",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageCircle, { className: "h-4 w-4" }), " Contact"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-center text-xs text-muted-foreground",
							children: "We reply within minutes during reception hours."
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mx-auto max-w-7xl px-6 py-20",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-10",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs uppercase tracking-[0.3em] text-gold",
						children: "Related experiences"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-3 font-display text-3xl text-sand-soft md:text-4xl",
						children: "More to explore"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid gap-6 md:grid-cols-3",
					children: related.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/experiences/$slug",
						params: { slug: r.slug },
						className: "group overflow-hidden rounded-3xl border border-gold/10 bg-card transition hover:border-gold/30",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "aspect-[4/3] overflow-hidden",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: r.img,
								alt: r.title,
								className: "h-full w-full object-cover transition duration-700 group-hover:scale-105"
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between p-5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "font-display text-lg text-sand-soft",
								children: r.title
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-muted-foreground",
								children: r.duration
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "h-4 w-4 text-gold transition group-hover:translate-x-1" })]
						})]
					}, r.slug))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Footer, {})
		]
	});
}
//#endregion
export { ExperienceDetail as component };
