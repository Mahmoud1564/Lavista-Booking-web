import { a as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { h as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { f as resolveRef } from "./booking-api-BfQOc4Uq.mjs";
import { f as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { E as Check, _ as Download, c as MessageCircle, h as House, l as MapPin } from "../_libs/lucide-react.mjs";
import { F as differenceInCalendarDays, P as format } from "../_libs/date-fns.mjs";
import { t as Route } from "./booking.confirmation._ref-C_0LUDr5.mjs";
import { t as findBooking } from "./bookings-DozuzODl.mjs";
import { i as fetchBookingByIdFn } from "./booking-server-fns-DTgYJGG6.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/booking.confirmation._ref-BMzNCRxd.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function fromStored(b) {
	return {
		ref: b.ref,
		firstName: b.firstName,
		lastName: b.lastName,
		email: b.email,
		phone: b.phone,
		guests: b.guests,
		checkIn: b.checkIn,
		checkOut: b.checkOut,
		nights: b.nights,
		total: b.total,
		roomType: b.roomType,
		rooms: b.rooms ?? [{
			id: b.roomId,
			type: b.roomType,
			price: Math.round(b.total / Math.max(1, b.nights)),
			nights: b.nights,
			subtotal: b.total
		}]
	};
}
function fromRemote(ref, b) {
	const ci = new Date(b.check_in);
	const co = new Date(b.check_out);
	const nights = Math.max(1, differenceInCalendarDays(co, ci));
	const rooms = b.rooms.map((r) => {
		const price = r.price_per_night ?? Math.round(b.total_price / Math.max(1, b.rooms.length) / nights);
		return {
			id: r.room_id,
			type: r.name,
			price,
			nights,
			subtotal: price * nights
		};
	});
	return {
		ref,
		firstName: b.guest?.name?.split(" ")[0] ?? "",
		lastName: b.guest?.name?.split(" ").slice(1).join(" ") ?? "",
		email: b.guest?.email ?? "",
		phone: b.guest?.phone ?? "",
		guests: b.num_guests,
		checkIn: b.check_in,
		checkOut: b.check_out,
		nights,
		total: b.total_price,
		roomType: rooms.map((r) => r.type).join(" + "),
		rooms
	};
}
function Confirmation() {
	const { ref } = Route.useParams();
	const [view, setView] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		const local = findBooking(ref);
		if (local) setView(fromStored(local));
		const id = resolveRef(ref);
		if (!id) return;
		fetchBookingByIdFn({ data: { id } }).then((remote) => {
			if (remote) setView(fromRemote(ref, remote));
		}).catch(() => {});
	}, [ref]);
	const download = () => {
		if (!view) return;
		const W = 1200;
		const H = 1500;
		const canvas = document.createElement("canvas");
		canvas.width = W;
		canvas.height = H;
		const ctx = canvas.getContext("2d");
		if (!ctx) return;
		const grad = ctx.createLinearGradient(0, 0, 0, H);
		grad.addColorStop(0, "#140C04");
		grad.addColorStop(1, "#0B0703");
		ctx.fillStyle = grad;
		ctx.fillRect(0, 0, W, H);
		ctx.fillStyle = "#D4A550";
		ctx.fillRect(80, 200, 120, 4);
		ctx.fillStyle = "#F5EBD8";
		ctx.font = "600 64px serif";
		ctx.fillText("Lavista.", 80, 160);
		ctx.fillStyle = "#D4A550";
		ctx.font = "500 22px sans-serif";
		ctx.fillText("BOOKING CONFIRMED", 80, 260);
		ctx.fillStyle = "#F5EBD8";
		ctx.font = "600 56px serif";
		ctx.fillText(`Reference  ${view.ref}`, 80, 330);
		ctx.fillStyle = "rgba(212,165,80,0.2)";
		ctx.fillRect(80, 380, W - 160, 1);
		const rows = [
			["Guest", `${view.firstName} ${view.lastName}`.trim()],
			["Phone", view.phone || "—"],
			["Email", view.email || "—"],
			["Room", view.roomType],
			["Guests", String(view.guests)],
			["Check-in", format(new Date(view.checkIn), "EEE, MMM d, yyyy")],
			["Check-out", format(new Date(view.checkOut), "EEE, MMM d, yyyy")],
			["Nights", String(view.nights)],
			["Total", `$${view.total}`]
		];
		let y = 440;
		rows.forEach(([k, v]) => {
			ctx.fillStyle = "#D4A550";
			ctx.font = "500 20px sans-serif";
			ctx.fillText(k.toUpperCase(), 80, y);
			ctx.fillStyle = "#F5EBD8";
			ctx.font = "400 32px sans-serif";
			ctx.fillText(v, 80, y + 44);
			y += 96;
		});
		ctx.fillStyle = "rgba(212,165,80,0.2)";
		ctx.fillRect(80, H - 200, W - 160, 1);
		ctx.fillStyle = "#A89A82";
		ctx.font = "400 22px sans-serif";
		ctx.fillText("Lavista · Nazlet El-Semman, Giza, Egypt", 80, H - 140);
		ctx.fillText("WhatsApp: +20 100 769 5392", 80, H - 100);
		canvas.toBlob((blob) => {
			if (!blob) return;
			const url = URL.createObjectURL(blob);
			const a = document.createElement("a");
			a.href = url;
			a.download = `lavista-${view.ref}.png`;
			a.click();
			URL.revokeObjectURL(url);
		}, "image/png");
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "mx-auto max-w-3xl px-6 py-16",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "flex h-12 w-12 items-center justify-center rounded-full bg-gold text-ink",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "h-5 w-5" })
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs uppercase tracking-[0.3em] text-gold",
				children: "Booking confirmed"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-3xl text-sand-soft md:text-4xl",
				children: "You're in. See you in Giza."
			})] })]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-8 rounded-3xl border border-gold/15 bg-card/60 p-6 md:p-8",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-baseline justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs uppercase tracking-[0.22em] text-gold",
						children: "Booking ID"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-2xl text-sand-soft",
						children: ref
					})]
				}),
				view ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
					className: "mt-6 grid gap-3 text-sm md:grid-cols-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Detail, {
							label: "Guest",
							value: `${view.firstName} ${view.lastName}`.trim()
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Detail, {
							label: "Email",
							value: view.email || "—"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Detail, {
							label: "Phone",
							value: view.phone || "—"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Detail, {
							label: "Room",
							value: view.roomType
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Detail, {
							label: "Guests",
							value: String(view.guests)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Detail, {
							label: "Check-in",
							value: format(new Date(view.checkIn), "EEE, MMM d, yyyy")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Detail, {
							label: "Check-out",
							value: format(new Date(view.checkOut), "EEE, MMM d, yyyy")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Detail, {
							label: "Nights",
							value: String(view.nights)
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-8 rounded-2xl border border-gold/15 bg-ink/30 p-5 md:p-6",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[10px] uppercase tracking-[0.22em] text-gold",
							children: "Price breakdown"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "mt-3 space-y-2 text-sm",
							children: view.rooms.map((r, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex items-baseline justify-between gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "min-w-0 truncate text-sand-soft/85",
									children: [r.type, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "ml-1 text-xs text-muted-foreground",
										children: [
											"($",
											r.price,
											" × ",
											r.nights,
											" ",
											r.nights === 1 ? "night" : "nights",
											")"
										]
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "shrink-0 text-sand-soft",
									children: ["$", r.subtotal]
								})]
							}, `${r.id}-${i}`))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-5 flex items-baseline justify-between gap-3 rounded-xl border border-gold/30 bg-gold/10 p-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xs font-medium uppercase tracking-[0.22em] text-gold",
								children: "Total"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "font-display text-4xl text-sand-soft md:text-5xl",
								children: ["$", view.total]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-[11px] text-muted-foreground",
							children: "Taxes included · pay on arrival or by card"
						})
					]
				})] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-6 text-sm text-muted-foreground",
					children: "Loading booking details…"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-6 flex items-center gap-2 text-sm text-sand-soft/85",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "h-3.5 w-3.5 text-gold" }), " Lavista · Nazlet El-Semman, Giza, Egypt"]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-8 flex flex-wrap items-center gap-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							onClick: download,
							disabled: !view,
							className: "inline-flex items-center gap-2 rounded-full bg-gold px-5 py-3 text-xs font-medium uppercase tracking-[0.2em] text-ink transition hover:bg-gold-soft disabled:opacity-50",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "h-4 w-4" }), " Download as PNG"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/",
							className: "inline-flex items-center gap-2 rounded-full border border-gold/30 px-5 py-3 text-xs uppercase tracking-[0.22em] text-sand-soft transition hover:bg-gold/10",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(House, { className: "h-3.5 w-3.5" }), " Back to home"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: "https://wa.me/201007695392",
							target: "_blank",
							rel: "noreferrer",
							"aria-label": "Contact reception on WhatsApp",
							title: "Contact",
							className: "ml-auto inline-flex h-11 w-11 items-center justify-center rounded-full border border-gold/30 text-gold transition hover:bg-gold/10",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageCircle, { className: "h-4 w-4" })
						})
					]
				})
			]
		})]
	});
}
function Detail({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-xl border border-gold/10 bg-ink/30 p-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-[10px] uppercase tracking-[0.22em] text-gold",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 text-sand-soft",
			children: value
		})]
	});
}
//#endregion
export { Confirmation as component };
