import { l as lazyRouteComponent, u as createFileRoute } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/booking.confirmation._ref-C_0LUDr5.js
var $$splitComponentImporter = () => import("./booking.confirmation._ref-BMzNCRxd.mjs");
var Route = createFileRoute("/booking/confirmation/$ref")({
	head: ({ params }) => ({ meta: [
		{ title: `Booking ${params.ref} confirmed — Lavista` },
		{
			name: "description",
			content: "Your stay at Lavista near the Pyramids of Giza is confirmed."
		},
		{
			name: "robots",
			content: "noindex,follow"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
