import { h as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { f as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { N as ArrowRight, P as ArrowLeft } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/booking-flow-ui-Bi1pQ2w4.js
var import_jsx_runtime = require_jsx_runtime();
function StepCard({ title, subtitle, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-3xl border border-gold/15 bg-card/60 p-6 md:p-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-2xl text-sand-soft",
				children: title
			}),
			subtitle && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted-foreground",
				children: subtitle
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-6",
				children
			})
		]
	});
}
function StepNav({ back, next, nextLabel = "Continue", disabled, onNext, nextAsLink = true }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mt-8 flex justify-between",
		children: [back ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
			to: back,
			className: "inline-flex items-center gap-2 rounded-full border border-gold/30 px-5 py-3 text-xs uppercase tracking-[0.22em] text-sand-soft transition hover:bg-gold/10",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "h-3.5 w-3.5" }), " Back"]
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {}), next && nextAsLink ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
			to: next,
			onClick: (e) => {
				if (disabled) e.preventDefault();
				else onNext?.();
			},
			"aria-disabled": disabled,
			className: `inline-flex items-center gap-2 rounded-full bg-gold px-6 py-3 text-sm font-medium uppercase tracking-[0.18em] text-ink transition hover:bg-gold-soft ${disabled ? "pointer-events-none opacity-50" : ""}`,
			children: [
				nextLabel,
				" ",
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "h-4 w-4" })
			]
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			onClick: onNext,
			disabled,
			className: "inline-flex items-center gap-2 rounded-full bg-gold px-6 py-3 text-sm font-medium uppercase tracking-[0.18em] text-ink transition hover:bg-gold-soft disabled:cursor-not-allowed disabled:opacity-50",
			children: [
				nextLabel,
				" ",
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "h-4 w-4" })
			]
		})]
	});
}
function FieldLabel({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
		className: "text-[10px] uppercase tracking-[0.22em] text-gold",
		children
	});
}
function TextInput({ label, value, onChange, type = "text", placeholder, required }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FieldLabel, { children: [label, required && " *"] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		type,
		value,
		placeholder,
		onChange: (e) => onChange(e.target.value),
		className: "mt-2 w-full rounded-xl border border-gold/20 bg-ink/30 p-3 text-sm text-sand-soft outline-none focus:border-gold"
	})] });
}
//#endregion
export { TextInput as i, StepCard as n, StepNav as r, FieldLabel as t };
