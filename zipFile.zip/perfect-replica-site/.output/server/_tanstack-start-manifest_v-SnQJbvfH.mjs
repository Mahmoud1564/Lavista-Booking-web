//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-SnQJbvfH.js
var tsrStartManifest = () => ({
	routes: {
		__root__: {
			filePath: "/home/runner/workspace/src/routes/__root.tsx",
			children: [
				"/",
				"/booking",
				"/manage-booking",
				"/sitemap.xml",
				"/experiences/$slug",
				"/rooms/$id"
			],
			assets: void 0,
			preloads: [
				"/assets/index-5Islgbg9.js",
				"/assets/link-CsShC-rv.js",
				"/assets/matchContext-ButN7OQN.js",
				"/assets/redirect-C-eRQtnH.js",
				"/assets/tslib.es6-Tae09705.js"
			]
		},
		"/": {
			filePath: "/home/runner/workspace/src/routes/index.tsx",
			children: void 0,
			assets: void 0,
			preloads: [
				"/assets/routes-_0USCEDp.js",
				"/assets/calendar-C_Om1MCq.js",
				"/assets/popover-3Wyulcmj.js",
				"/assets/dist-C8QakbHo.js",
				"/assets/format-DiZflMCn.js",
				"/assets/differenceInCalendarDays-BK1ZjWX5.js",
				"/assets/carousel-BcXKhi5d.js",
				"/assets/createLucideIcon-orx4IUyc.js",
				"/assets/arrow-right-qHEWS3gm.js",
				"/assets/Footer-BgJMZ0QU.js",
				"/assets/message-circle-vBB47giE.js",
				"/assets/search-BJlnKS4M.js",
				"/assets/users-CUKlAsux.js",
				"/assets/booking-context-B2ZovxVR.js",
				"/assets/preselect-room-NcUZaX_L.js",
				"/assets/use-content-jLc09cpB.js",
				"/assets/use-rooms-xBXnHinV.js"
			]
		},
		"/booking": {
			filePath: "/home/runner/workspace/src/routes/booking.tsx",
			children: [
				"/booking/dates",
				"/booking/extras",
				"/booking/guest",
				"/booking/payment",
				"/booking/rooms",
				"/booking/",
				"/booking/confirmation/$ref"
			],
			assets: void 0,
			preloads: [
				"/assets/booking-DUgyjYEw.js",
				"/assets/format-DiZflMCn.js",
				"/assets/differenceInCalendarDays-BK1ZjWX5.js",
				"/assets/arrow-left-C0obLcZA.js",
				"/assets/check-CIlnx28k.js",
				"/assets/Footer-BgJMZ0QU.js",
				"/assets/message-circle-vBB47giE.js",
				"/assets/booking-context-B2ZovxVR.js",
				"/assets/booking-flow-CPaIE9LA.js",
				"/assets/use-rooms-xBXnHinV.js"
			]
		},
		"/manage-booking": {
			filePath: "/home/runner/workspace/src/routes/manage-booking.tsx",
			children: void 0,
			assets: void 0,
			preloads: [
				"/assets/manage-booking-D3o3uDYk.js",
				"/assets/format-DiZflMCn.js",
				"/assets/differenceInCalendarDays-BK1ZjWX5.js",
				"/assets/createLucideIcon-orx4IUyc.js",
				"/assets/arrow-left-C0obLcZA.js",
				"/assets/download-CQHazL0f.js",
				"/assets/Footer-BgJMZ0QU.js",
				"/assets/message-circle-vBB47giE.js",
				"/assets/search-BJlnKS4M.js",
				"/assets/booking-api-Cac8pRFM.js",
				"/assets/bookings-C7asGgck.js"
			]
		},
		"/booking/dates": {
			filePath: "/home/runner/workspace/src/routes/booking.dates.tsx",
			children: void 0,
			assets: void 0,
			preloads: [
				"/assets/booking.dates-BOVkn3Rv.js",
				"/assets/calendar-C_Om1MCq.js",
				"/assets/popover-3Wyulcmj.js",
				"/assets/dist-C8QakbHo.js",
				"/assets/createLucideIcon-orx4IUyc.js",
				"/assets/calendar-days-B_mtDQZx.js",
				"/assets/users-CUKlAsux.js",
				"/assets/booking-flow-ui-BBzGTnj8.js"
			]
		},
		"/booking/extras": {
			filePath: "/home/runner/workspace/src/routes/booking.extras.tsx",
			children: void 0,
			assets: void 0,
			preloads: ["/assets/booking.extras-BPwyieKX.js", "/assets/booking-flow-ui-BBzGTnj8.js"]
		},
		"/booking/guest": {
			filePath: "/home/runner/workspace/src/routes/booking.guest.tsx",
			children: void 0,
			assets: void 0,
			preloads: [
				"/assets/booking.guest-BhvzwIcH.js",
				"/assets/popover-3Wyulcmj.js",
				"/assets/search-BJlnKS4M.js",
				"/assets/booking-flow-ui-BBzGTnj8.js"
			]
		},
		"/booking/payment": {
			filePath: "/home/runner/workspace/src/routes/booking.payment.tsx",
			children: void 0,
			assets: void 0,
			preloads: [
				"/assets/booking.payment-DCPwiy2j.js",
				"/assets/booking-server-fns-BSEXBXXf.js",
				"/assets/createLucideIcon-orx4IUyc.js",
				"/assets/circle-alert-B-IVAjuZ.js",
				"/assets/booking-flow-ui-BBzGTnj8.js",
				"/assets/booking-api-Cac8pRFM.js",
				"/assets/bookings-C7asGgck.js"
			]
		},
		"/booking/rooms": {
			filePath: "/home/runner/workspace/src/routes/booking.rooms.tsx",
			children: void 0,
			assets: void 0,
			preloads: [
				"/assets/booking.rooms-CsHAkSM0.js",
				"/assets/createLucideIcon-orx4IUyc.js",
				"/assets/circle-alert-B-IVAjuZ.js",
				"/assets/booking-flow-ui-BBzGTnj8.js"
			]
		},
		"/experiences/$slug": {
			filePath: "/home/runner/workspace/src/routes/experiences.$slug.tsx",
			children: void 0,
			assets: void 0,
			preloads: [
				"/assets/experiences._slug-CKNEZUyE.js",
				"/assets/carousel-BcXKhi5d.js",
				"/assets/createLucideIcon-orx4IUyc.js",
				"/assets/arrow-left-C0obLcZA.js",
				"/assets/arrow-right-qHEWS3gm.js",
				"/assets/calendar-days-B_mtDQZx.js",
				"/assets/Footer-BgJMZ0QU.js",
				"/assets/message-circle-vBB47giE.js",
				"/assets/use-content-jLc09cpB.js"
			]
		},
		"/rooms/$id": {
			filePath: "/home/runner/workspace/src/routes/rooms.$id.tsx",
			children: void 0,
			assets: void 0,
			preloads: [
				"/assets/rooms._id-XPWBsRAW.js",
				"/assets/carousel-BcXKhi5d.js",
				"/assets/arrow-left-C0obLcZA.js",
				"/assets/arrow-right-qHEWS3gm.js",
				"/assets/calendar-days-B_mtDQZx.js",
				"/assets/check-CIlnx28k.js",
				"/assets/Footer-BgJMZ0QU.js",
				"/assets/message-circle-vBB47giE.js",
				"/assets/users-CUKlAsux.js",
				"/assets/preselect-room-NcUZaX_L.js",
				"/assets/use-rooms-xBXnHinV.js"
			]
		},
		"/booking/confirmation/$ref": {
			filePath: "/home/runner/workspace/src/routes/booking.confirmation.$ref.tsx",
			children: void 0,
			assets: void 0,
			preloads: [
				"/assets/booking.confirmation._ref-4oZpHb8O.js",
				"/assets/booking-server-fns-BSEXBXXf.js",
				"/assets/createLucideIcon-orx4IUyc.js",
				"/assets/download-CQHazL0f.js",
				"/assets/booking-api-Cac8pRFM.js",
				"/assets/bookings-C7asGgck.js"
			]
		}
	},
	clientEntry: "/assets/index-5Islgbg9.js"
});
//#endregion
export { tsrStartManifest };
