//#region node_modules/.nitro/vite/services/ssr/assets/__23tanstack-start-server-fn-resolver-CecYBZW6.js
var manifest = {
	"6c04165ebeb7dbcb085f6c020bad163d0446ff0695dc1ccefaa35da7f01cae16": {
		functionName: "createGuestFn_createServerFn_handler",
		importer: () => import("./_ssr/booking-server-fns-NarS88HQ.mjs")
	},
	"f8366f9fe0cdeb3fbc64c197d2506796d98541d104f05f99fdd7de43d032c532": {
		functionName: "createBookingFn_createServerFn_handler",
		importer: () => import("./_ssr/booking-server-fns-NarS88HQ.mjs")
	},
	"688df4ef3ee04c076628739d15f87e185cf06ba50cd1c2b18a247170923c752a": {
		functionName: "addBookingRoomFn_createServerFn_handler",
		importer: () => import("./_ssr/booking-server-fns-NarS88HQ.mjs")
	},
	"1c0d2efabadc575ade07bfcf5a8b59e8c76ce319bc2cd92c6ea5dffc846f0f44": {
		functionName: "fetchBookingByIdFn_createServerFn_handler",
		importer: () => import("./_ssr/booking-server-fns-NarS88HQ.mjs")
	}
};
async function getServerFnById(id, access) {
	const serverFnInfo = manifest[id];
	if (!serverFnInfo) throw new Error("Server function info not found for " + id);
	const fnModule = serverFnInfo.module ?? await serverFnInfo.importer();
	if (!fnModule) throw new Error("Server function module not resolved for " + id);
	const action = fnModule[serverFnInfo.functionName];
	if (!action) throw new Error("Server function module export not resolved for serverFn ID: " + id);
	return action;
}
//#endregion
export { getServerFnById as t };
